/**
 * Create the first platform admin and the first regulator (the KDB Managing
 * Director, who onboards the other regulators). Run once per environment:
 *
 *   ADMIN_PHONE=0700000001 ADMIN_PIN=4821 REGULATOR_PHONE=0700000002 REGULATOR_PIN=7314 npm run seed
 */
import { pool, withTx } from '../src/db/pool.js';
import { migrate } from '../src/db/migrate.js';
import { SYSTEM_ACTOR } from '../src/lib/actor.js';
import { newId } from '../src/lib/ids.js';
import { normalisePhone } from '../src/lib/phone.js';
import { hashPin } from '../src/modules/auth/service.js';
import { grantRole } from '../src/modules/admin/service.js';

async function ensureUser(phoneIn: string, name: string, pin: string, role: 'platform_admin' | 'regulator') {
  const phone = normalisePhone(phoneIn);
  return withTx(async (tx) => {
    let userId = (await tx.query(`SELECT user_id FROM app_user WHERE phone = $1`, [phone])).rows[0]?.user_id as string | undefined;
    if (!userId) {
      userId = newId('US');
      await tx.query(
        `INSERT INTO app_user(user_id, phone, name, pin_hash, created_by, channel) VALUES ($1,$2,$3,$4,'SYSTEM','system')`,
        [userId, phone, name, await hashPin(pin)],
      );
    }
    await grantRole(tx, SYSTEM_ACTOR, { userId, role }, { skipAuth: true });
    console.log(`${role}: ${phone} (${userId})`);
  });
}

await migrate();
const env = process.env;
if (!env.ADMIN_PHONE || !env.ADMIN_PIN) throw new Error('Set ADMIN_PHONE and ADMIN_PIN');
await ensureUser(env.ADMIN_PHONE, env.ADMIN_NAME ?? 'Platform admin', env.ADMIN_PIN, 'platform_admin');
if (env.REGULATOR_PHONE && env.REGULATOR_PIN) {
  await ensureUser(env.REGULATOR_PHONE, env.REGULATOR_NAME ?? 'KDB Managing Director', env.REGULATOR_PIN, 'regulator');
}
await pool.end();
