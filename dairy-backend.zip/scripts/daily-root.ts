/**
 * Store yesterday's root hash (Nairobi time). Schedule shortly after
 * midnight, e.g. cron `15 0 * * *` with TZ=Africa/Nairobi.
 * Pass a date to (re)check a specific day: npm run daily-root -- 2026-11-03
 */
import { pool } from '../src/db/pool.js';
import { nairobiDate } from '../src/lib/clock.js';
import { storeDailyRoot } from '../src/modules/regulator/service.js';

const date = process.argv[2] ?? nairobiDate(new Date(Date.now() - 24 * 3600_000));
const r = await storeDailyRoot(date);
console.log(JSON.stringify(r));
await pool.end();
