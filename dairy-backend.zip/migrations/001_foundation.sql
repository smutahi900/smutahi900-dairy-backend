-- Step 1 of the build order: users, roles, idempotency, trail, hash chain, daily root.

CREATE TABLE app_user (
  user_id            text PRIMARY KEY,               -- US-
  phone              text NOT NULL UNIQUE,           -- E.164, e.g. +254712345678
  name               text NOT NULL,
  pin_hash           text,                           -- null until the user sets a PIN
  failed_pin_count   integer NOT NULL DEFAULT 0,
  locked_until       timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now(),
  created_by         text,
  channel            text NOT NULL
);

-- Register D33: roles with a scope. One phone can hold several roles.
CREATE TABLE role_grant (
  grant_id     text PRIMARY KEY,                     -- RG-
  user_id      text NOT NULL REFERENCES app_user(user_id),
  role         text NOT NULL,
  scope_type   text NOT NULL,                        -- platform | cooperative | farm | vendor | transporter | collector
  scope_id     text,                                 -- null for platform scope
  granted_at   timestamptz NOT NULL DEFAULT now(),
  granted_by   text,
  revoked_at   timestamptz,
  revoked_by   text
);
CREATE INDEX role_grant_user ON role_grant(user_id) WHERE revoked_at IS NULL;
CREATE UNIQUE INDEX role_grant_active ON role_grant(user_id, role, scope_type, coalesce(scope_id, ''))
  WHERE revoked_at IS NULL;

-- Every refused call (and every grant change) is logged.
CREATE TABLE access_log (
  id          bigserial PRIMARY KEY,
  at          timestamptz NOT NULL DEFAULT now(),
  user_id     text,
  channel     text,
  action      text NOT NULL,
  resource    text,
  allowed     boolean NOT NULL,
  reason      text
);

CREATE TABLE idempotency_key (
  actor_id         text NOT NULL,
  key              text NOT NULL,
  action           text NOT NULL,
  request_hash     text NOT NULL,
  response_status  integer,
  response_body    jsonb,
  created_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (actor_id, key)
);

-- Hash chain. One row per chain holds the head; every hashed record or
-- trail event adds a link. Rows in chain_link are never changed.
CREATE TABLE chain_head (
  chain_key  text PRIMARY KEY,
  seq        bigint NOT NULL,
  last_hash  text NOT NULL
);

CREATE TABLE chain_link (
  chain_key    text NOT NULL,
  seq          bigint NOT NULL,
  record_type  text NOT NULL,
  record_id    text NOT NULL,
  prev_hash    text NOT NULL,
  hash         text NOT NULL,
  payload      jsonb NOT NULL,                       -- the canonical JSON that was hashed
  at           timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (chain_key, seq)
);
CREATE INDEX chain_link_at ON chain_link(at);
CREATE INDEX chain_link_record ON chain_link(record_id);

CREATE TABLE trail_event (
  event_id     text PRIMARY KEY,                     -- TE-
  record_id    text NOT NULL,
  record_type  text NOT NULL,
  event        text NOT NULL,
  actor        text NOT NULL,
  channel      text NOT NULL,
  at           timestamptz NOT NULL DEFAULT now(),
  from_status  text,
  to_status    text,
  amount       bigint,
  reference    text,
  reason       text,
  data         jsonb,
  prev_hash    text NOT NULL,
  hash         text NOT NULL
);
CREATE INDEX trail_event_record ON trail_event(record_id, at);

-- Written only by the daily-root job, never by an API call.
CREATE TABLE daily_root (
  root_date     date PRIMARY KEY,
  root_hash     text NOT NULL,
  link_count    integer NOT NULL,
  computed_at   timestamptz NOT NULL DEFAULT now()
);

-- Generic guards: some tables may never be updated or deleted.
CREATE FUNCTION forbid_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'RECORD_LOCKED: % on % is not allowed', TG_OP, TG_TABLE_NAME
    USING ERRCODE = 'P0001';
END $$;

CREATE TRIGGER chain_link_append_only BEFORE UPDATE OR DELETE ON chain_link
  FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER trail_event_append_only BEFORE UPDATE OR DELETE ON trail_event
  FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER daily_root_append_only BEFORE UPDATE OR DELETE ON daily_root
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Corrections never edit the original record.
CREATE TABLE correction (
  correction_id  text PRIMARY KEY,                   -- CR-
  record_id      text NOT NULL,
  record_type    text NOT NULL,
  reason         text NOT NULL,
  data           jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at     timestamptz NOT NULL DEFAULT now(),
  created_by     text NOT NULL,
  channel        text NOT NULL,
  prev_hash      text NOT NULL,
  hash           text NOT NULL
);
CREATE TRIGGER correction_append_only BEFORE UPDATE OR DELETE ON correction
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Messages are sent by the back end only. A worker hands them to the SMS
-- provider (Africa's Talking or other); until then they wait here.
CREATE TABLE sms_outbox (
  sms_id      text PRIMARY KEY,                      -- SM-
  phone       text NOT NULL,
  body        text NOT NULL,
  purpose     text NOT NULL,
  record_id   text,
  status      text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','failed')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  sent_at     timestamptz,
  provider_ref text
);
