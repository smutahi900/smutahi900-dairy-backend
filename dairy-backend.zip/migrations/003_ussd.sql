-- USSD gateway sessions. A session is marked signed in after a correct PIN,
-- so later hops of the same session do not re-check (and re-count) the PIN.
CREATE TABLE ussd_session (
  session_id   text PRIMARY KEY,
  phone        text NOT NULL,
  user_id      text REFERENCES app_user(user_id),
  pin_ok_at    timestamptz,
  started_at   timestamptz NOT NULL DEFAULT now(),
  last_text    text
);
