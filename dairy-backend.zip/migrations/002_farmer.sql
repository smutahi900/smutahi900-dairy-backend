-- Step 2 of the build order: cooperatives, farms, animals, AMRs, farm lots.

CREATE TABLE cooperative (
  coop_id     text PRIMARY KEY,                      -- CO-
  name        text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  created_by  text NOT NULL,
  channel     text NOT NULL
);

CREATE TABLE farm (
  farm_id          text PRIMARY KEY,                 -- farm code FARM-XXXX-XXXX
  coop_id          text NOT NULL REFERENCES cooperative(coop_id),
  name             text NOT NULL,
  phone            text NOT NULL,
  identity_number  text NOT NULL,
  route            text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  created_by       text NOT NULL,
  channel          text NOT NULL,
  prev_hash        text NOT NULL,
  hash             text NOT NULL
);

CREATE TABLE animal (
  animal_id   text PRIMARY KEY,                      -- AN-
  farm_id     text NOT NULL REFERENCES farm(farm_id),
  tag         text NOT NULL,
  name        text,
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  created_by  text NOT NULL,
  channel     text NOT NULL,
  UNIQUE (farm_id, tag)
);

-- Animal milk record. Litres are stored in tenths (litres to one decimal).
CREATE TABLE amr (
  amr_id       text PRIMARY KEY,                     -- amr_
  farm_id      text NOT NULL REFERENCES farm(farm_id),
  animal_id    text NOT NULL REFERENCES animal(animal_id),
  milk_date    date NOT NULL,
  session      text NOT NULL CHECK (session IN ('morning','afternoon','evening')),
  litres_x10   integer NOT NULL CHECK (litres_x10 > 0),
  recorded_at  timestamptz NOT NULL DEFAULT now(),
  locked       boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now(),
  created_by   text NOT NULL,
  channel      text NOT NULL,
  device_id    text,
  prev_hash    text NOT NULL,
  hash         text NOT NULL
);
CREATE INDEX amr_farm_date ON amr(farm_id, milk_date, session);

-- An AMR may only change by being locked; it can never be deleted.
CREATE FUNCTION amr_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'RECORD_LOCKED: delete on amr is not allowed' USING ERRCODE = 'P0001';
  END IF;
  IF (to_jsonb(NEW) - 'locked') <> (to_jsonb(OLD) - 'locked') OR (OLD.locked AND NOT NEW.locked) THEN
    RAISE EXCEPTION 'RECORD_LOCKED: amr % can only be locked', OLD.amr_id USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER amr_guard BEFORE UPDATE OR DELETE ON amr FOR EACH ROW EXECUTE FUNCTION amr_guard();

CREATE TABLE farm_lot (
  farm_lot_id          text PRIMARY KEY,             -- FL-
  farm_id              text NOT NULL REFERENCES farm(farm_id),
  lot_date             date NOT NULL,
  scope                text NOT NULL CHECK (scope IN ('morning','afternoon','evening','all')),
  committed_x10        integer NOT NULL CHECK (committed_x10 > 0),
  -- status columns: the only columns that may change, and only through a status step
  status               text NOT NULL DEFAULT 'awaiting_collection' CHECK (status IN (
                         'awaiting_collection','collected','downgraded','received',
                         'in_production','invoiced','paid','withdrawn')),
  collected_at         timestamptz,
  collected_x10        integer,
  variance_x10         integer,
  grade                text,
  collection_batch_id  text,
  receiving_lot_id     text,
  flag_held            boolean NOT NULL DEFAULT false,
  flag_disputed        boolean NOT NULL DEFAULT false,
  flag_rejected        boolean NOT NULL DEFAULT false,
  invoice_id           text,
  -- fixed at creation
  created_at           timestamptz NOT NULL DEFAULT now(),
  created_by           text NOT NULL,
  channel              text NOT NULL,
  prev_hash            text NOT NULL,
  hash                 text NOT NULL
);
CREATE INDEX farm_lot_farm_date ON farm_lot(farm_id, lot_date);

-- Litres a farm lot took from each AMR.
CREATE TABLE farm_lot_amr (
  farm_lot_id  text NOT NULL REFERENCES farm_lot(farm_lot_id),
  amr_id       text NOT NULL REFERENCES amr(amr_id),
  litres_x10   integer NOT NULL CHECK (litres_x10 > 0),
  PRIMARY KEY (farm_lot_id, amr_id)
);
CREATE TRIGGER farm_lot_amr_append_only BEFORE UPDATE OR DELETE ON farm_lot_amr
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

CREATE FUNCTION farm_lot_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  fixed text[] := ARRAY['farm_lot_id','farm_id','lot_date','scope','committed_x10',
                        'created_at','created_by','channel','prev_hash','hash'];
  c text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'RECORD_LOCKED: delete on farm_lot is not allowed' USING ERRCODE = 'P0001';
  END IF;
  FOREACH c IN ARRAY fixed LOOP
    IF to_jsonb(NEW) -> c IS DISTINCT FROM to_jsonb(OLD) -> c THEN
      RAISE EXCEPTION 'RECORD_LOCKED: farm_lot.% cannot change', c USING ERRCODE = 'P0001';
    END IF;
  END LOOP;
  RETURN NEW;
END $$;
CREATE TRIGGER farm_lot_guard BEFORE UPDATE OR DELETE ON farm_lot FOR EACH ROW EXECUTE FUNCTION farm_lot_guard();

CREATE TRIGGER farm_append_only_delete BEFORE DELETE ON farm FOR EACH ROW EXECUTE FUNCTION forbid_change();
