import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    env: { NODE_ENV: 'test' },
    globalSetup: ['test/global-setup.ts'],
    // One shared test database: run files one after another.
    fileParallelism: false,
    testTimeout: 20000,
  },
});
