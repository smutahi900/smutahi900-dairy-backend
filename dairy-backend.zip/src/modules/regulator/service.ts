import { pool, withTx } from '../../db/pool.js';
import type { Actor } from '../../lib/actor.js';
import { verifyChain } from '../../lib/chain.js';
import { AppError } from '../../lib/errors.js';
import { sha256 } from '../../lib/hash.js';
import { authorize } from '../../lib/rbac.js';

type Db = { query: typeof pool.query };

/** Root hash over every chain link written on a Nairobi calendar day. */
export async function computeDailyRoot(date: string, db: Db = pool) {
  const r = await db.query<{ chain_key: string; seq: number; hash: string }>(
    `SELECT chain_key, seq, hash FROM chain_link
      WHERE at >= ($1::date)::timestamp AT TIME ZONE 'Africa/Nairobi'
        AND at <  ($1::date + 1)::timestamp AT TIME ZONE 'Africa/Nairobi'
      ORDER BY at, chain_key, seq`,
    [date],
  );
  const rootHash = sha256(r.rows.map((l) => `${l.chain_key}:${l.seq}:${l.hash}`).join('\n'));
  return { date, rootHash, linkCount: r.rows.length };
}

/**
 * Run by the daily job only (scripts/daily-root.ts), never by an API call.
 * A day already stored is not overwritten.
 */
export async function storeDailyRoot(date: string) {
  return withTx(async (tx) => {
    const existing = await tx.query(`SELECT root_hash, link_count FROM daily_root WHERE root_date = $1`, [date]);
    if (existing.rows[0]) return { date, rootHash: existing.rows[0].root_hash, linkCount: existing.rows[0].link_count, stored: false };
    const root = await computeDailyRoot(date, tx);
    await tx.query(`INSERT INTO daily_root(root_date, root_hash, link_count) VALUES ($1,$2,$3)`, [
      date, root.rootHash, root.linkCount,
    ]);
    return { ...root, stored: true };
  });
}

export async function getDailyRoot(actor: Actor, date: string) {
  await authorize(actor, 'regulator.read');
  const r = await pool.query<{ root_hash: string; link_count: number; computed_at: Date }>(
    `SELECT root_hash, link_count, computed_at FROM daily_root WHERE root_date = $1`,
    [date],
  );
  if (!r.rows[0]) throw new AppError('NOT_FOUND', `No root stored for ${date}`);
  const now = await computeDailyRoot(date);
  return {
    date,
    rootHash: r.rows[0].root_hash,
    linkCount: r.rows[0].link_count,
    computedAt: r.rows[0].computed_at,
    matchesRecords: now.rootHash === r.rows[0].root_hash,
  };
}

export async function checkChain(actor: Actor, chainKey: string) {
  await authorize(actor, 'regulator.read');
  return verifyChain(pool, chainKey);
}
