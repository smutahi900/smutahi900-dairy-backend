import type { Tx } from '../../db/pool.js';
import { pool } from '../../db/pool.js';
import type { Actor } from '../../lib/actor.js';
import { appendLink, chainKeys } from '../../lib/chain.js';
import { now, todayNairobi } from '../../lib/clock.js';
import { config } from '../../config.js';
import { AppError } from '../../lib/errors.js';
import { newFarmCode, newId } from '../../lib/ids.js';
import { fromX10, toX10 } from '../../lib/litres.js';
import { normalisePhone } from '../../lib/phone.js';
import { authorize } from '../../lib/rbac.js';
import { stepStatus, writeTrail } from '../../lib/trail.js';
import { findOrCreateUser, grantRole } from '../admin/service.js';

export const SESSIONS = ['morning', 'afternoon', 'evening'] as const;
export type Session = (typeof SESSIONS)[number];
export type LotScope = Session | 'all';

type Db = Pick<Tx, 'query'>;

// ---------------------------------------------------------------- farms

export interface CreateFarmInput {
  name: string;
  phone: string;
  identityNumber: string;
  route?: string | null;
  farmerName?: string;
}

export async function createFarm(tx: Tx, actor: Actor, coopId: string, input: CreateFarmInput) {
  await authorize(actor, 'farm.create', { coopId });
  const coop = await tx.query(`SELECT 1 FROM cooperative WHERE coop_id = $1`, [coopId]);
  if (!coop.rows[0]) throw new AppError('NOT_FOUND', 'Cooperative not found');

  const phone = normalisePhone(input.phone);
  const farmId = newFarmCode();
  const createdAt = now();
  const payload = {
    farmId, coopId, name: input.name, phone, identityNumber: input.identityNumber, route: input.route ?? null,
    createdAt: createdAt.toISOString(), createdBy: actor.userId, channel: actor.channel,
  };
  const link = await appendLink(tx, chainKeys.farm(farmId), 'farm', farmId, payload);
  await tx.query(
    `INSERT INTO farm(farm_id, coop_id, name, phone, identity_number, route, created_at, created_by, channel, prev_hash, hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [farmId, coopId, input.name, phone, input.identityNumber, input.route ?? null, createdAt, actor.userId,
      actor.channel, link.prevHash, link.hash],
  );
  const user = await findOrCreateUser(tx, actor, phone, input.farmerName ?? input.name);
  // The farm.create check above already scoped this to the actor's cooperative.
  await grantRole(tx, actor, { userId: user.userId, role: 'farmer', scopeId: farmId }, { skipAuth: true });
  return { farmId, coopId, name: input.name, phone, route: input.route ?? null, farmerUserId: user.userId };
}

async function lockFarm(tx: Tx, farmId: string) {
  const r = await tx.query<{ farm_id: string; phone: string }>(
    `SELECT farm_id, phone FROM farm WHERE farm_id = $1 FOR UPDATE`,
    [farmId],
  );
  if (!r.rows[0]) throw new AppError('FARM_NOT_FOUND', 'Farm not found');
  return r.rows[0];
}

export async function getFarm(actor: Actor, farmId: string, db: Db = pool) {
  await authorize(actor, 'farm.read', { farmId });
  const r = await db.query(
    `SELECT farm_id AS "farmId", coop_id AS "coopId", name, phone, route, created_at AS "createdAt" FROM farm WHERE farm_id = $1`,
    [farmId],
  );
  if (!r.rows[0]) throw new AppError('FARM_NOT_FOUND', 'Farm not found');
  return r.rows[0];
}

/** Farms where this user holds the farmer role (used by USSD and the farmer web home). */
export async function farmsOfFarmer(actor: Actor): Promise<string[]> {
  return actor.grants.filter((g) => g.role === 'farmer' && g.scopeId).map((g) => g.scopeId!);
}

// ---------------------------------------------------------------- animals

export async function addAnimal(tx: Tx, actor: Actor, farmId: string, input: { tag: string; name?: string | null }) {
  await authorize(actor, 'animal.create', { farmId });
  await lockFarm(tx, farmId);
  const dup = await tx.query(`SELECT 1 FROM animal WHERE farm_id = $1 AND tag = $2`, [farmId, input.tag]);
  if (dup.rows[0]) throw new AppError('VALIDATION_FAILED', `Tag ${input.tag} is already on this farm`);
  const animalId = newId('AN');
  await tx.query(
    `INSERT INTO animal(animal_id, farm_id, tag, name, created_by, channel) VALUES ($1,$2,$3,$4,$5,$6)`,
    [animalId, farmId, input.tag, input.name ?? null, actor.userId, actor.channel],
  );
  return { animalId, farmId, tag: input.tag, name: input.name ?? null };
}

export async function listAnimals(actor: Actor, farmId: string, db: Db = pool) {
  await authorize(actor, 'animal.read', { farmId });
  const r = await db.query(
    `SELECT animal_id AS "animalId", tag, name FROM animal WHERE farm_id = $1 AND active ORDER BY tag`,
    [farmId],
  );
  return r.rows as { animalId: string; tag: string; name: string | null }[];
}

// ---------------------------------------------------------------- AMRs

export interface AmrInput {
  milkDate: string;
  session: Session;
  animalId: string;
  litres: number;
  confirmLarge?: boolean;
  deviceId?: string | null;
}

export async function recordAmr(tx: Tx, actor: Actor, farmId: string, input: AmrInput) {
  await authorize(actor, 'amr.create', { farmId });
  await lockFarm(tx, farmId);

  if (input.milkDate > todayNairobi()) throw new AppError('DATE_IN_FUTURE', 'Milk date cannot be in the future');
  const litresX10 = toX10(input.litres);
  if (litresX10 > config.amrConfirmAboveLitres * 10 && !input.confirmLarge) {
    throw new AppError('CONFIRMATION_REQUIRED', `More than ${config.amrConfirmAboveLitres} L needs confirmation`, {
      litres: input.litres,
    });
  }
  const animal = await tx.query(`SELECT 1 FROM animal WHERE animal_id = $1 AND farm_id = $2 AND active`, [
    input.animalId, farmId,
  ]);
  if (!animal.rows[0]) throw new AppError('ANIMAL_NOT_FOUND', 'Animal not found on this farm');

  const locked = await tx.query(
    `SELECT 1 FROM amr WHERE farm_id = $1 AND milk_date = $2 AND session = $3 AND locked LIMIT 1`,
    [farmId, input.milkDate, input.session],
  );
  if (locked.rows[0]) {
    throw new AppError('RECORD_LOCKED', `The ${input.session} session of ${input.milkDate} is committed and locked`);
  }

  const amrId = newId('amr');
  const recordedAt = now();
  const payload = {
    amrId, farmId, animalId: input.animalId, milkDate: input.milkDate, session: input.session, litresX10,
    recordedAt: recordedAt.toISOString(), createdBy: actor.userId, channel: actor.channel, deviceId: input.deviceId ?? null,
  };
  const link = await appendLink(tx, chainKeys.farm(farmId), 'amr', amrId, payload);
  await tx.query(
    `INSERT INTO amr(amr_id, farm_id, animal_id, milk_date, session, litres_x10, recorded_at, created_at, created_by,
       channel, device_id, prev_hash, hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$7,$8,$9,$10,$11,$12)`,
    [amrId, farmId, input.animalId, input.milkDate, input.session, litresX10, recordedAt, actor.userId,
      actor.channel, input.deviceId ?? null, link.prevHash, link.hash],
  );
  return {
    amrId, farmId, animalId: input.animalId, milkDate: input.milkDate, session: input.session,
    litres: litresX10 / 10, recordedAt: recordedAt.toISOString(), locked: false, hash: link.hash,
  };
}

export async function recentMilk(actor: Actor, farmId: string, date: string, db: Db = pool) {
  await authorize(actor, 'amr.read', { farmId });
  const r = await db.query<{ amrId: string; animalId: string; tag: string; session: Session; litres_x10: number; recordedAt: Date; locked: boolean }>(
    `SELECT a.amr_id AS "amrId", a.animal_id AS "animalId", an.tag, a.session, a.litres_x10,
            a.recorded_at AS "recordedAt", a.locked
       FROM amr a JOIN animal an USING (animal_id)
      WHERE a.farm_id = $1 AND a.milk_date = $2
      ORDER BY a.recorded_at`,
    [farmId, date],
  );
  return r.rows.map(({ litres_x10, ...a }) => ({ ...a, litres: litres_x10 / 10 }));
}

/** Litres of each AMR not yet taken by an active (not withdrawn) farm lot. */
async function amrsWithFree(db: Db, farmId: string, date: string, session?: Session) {
  const r = await db.query<{ amr_id: string; session: Session; litres_x10: number; taken_x10: number; locked: boolean }>(
    `SELECT a.amr_id, a.session, a.litres_x10, a.locked,
            coalesce((SELECT sum(fla.litres_x10) FROM farm_lot_amr fla JOIN farm_lot fl USING (farm_lot_id)
                       WHERE fla.amr_id = a.amr_id AND fl.status <> 'withdrawn'), 0)::int AS taken_x10
       FROM amr a
      WHERE a.farm_id = $1 AND a.milk_date = $2 AND ($3::text IS NULL OR a.session = $3)
      ORDER BY array_position(ARRAY['morning','afternoon','evening'], a.session), a.recorded_at, a.amr_id`,
    [farmId, date, session ?? null],
  );
  return r.rows.map((a) => ({ ...a, free_x10: a.litres_x10 - a.taken_x10 }));
}

export async function milkSessions(actor: Actor, farmId: string, date: string, db: Db = pool) {
  await authorize(actor, 'amr.read', { farmId });
  const amrs = await amrsWithFree(db, farmId, date);
  const sessions = SESSIONS.map((s) => {
    const of = amrs.filter((a) => a.session === s);
    const gross = of.reduce((n, a) => n + a.litres_x10, 0);
    const free = of.reduce((n, a) => n + a.free_x10, 0);
    return {
      session: s,
      records: of.length,
      grossLitres: gross / 10,
      committedLitres: (gross - free) / 10,
      freeLitres: free / 10,
      locked: of.some((a) => a.locked),
    };
  });
  const sum = (k: 'grossLitres' | 'committedLitres' | 'freeLitres') =>
    Math.round(sessions.reduce((n, s) => n + s[k] * 10, 0)) / 10;
  return { farmId, date, sessions, total: { grossLitres: sum('grossLitres'), committedLitres: sum('committedLitres'), freeLitres: sum('freeLitres') } };
}

// ---------------------------------------------------------------- farm lots

export interface CommitInput {
  date: string;
  scope: LotScope;
  /** Optional: commit only part of the free litres. Default is all free litres in scope. */
  litres?: number;
}

export async function commitFarmLot(tx: Tx, actor: Actor, farmId: string, input: CommitInput) {
  await authorize(actor, 'farm_lot.create', { farmId });
  if (input.date !== todayNairobi()) {
    throw new AppError('NOT_TODAY', 'Only today\'s milk can be committed (cut-off is midnight, Nairobi time)');
  }
  await lockFarm(tx, farmId);

  const amrs = (await amrsWithFree(tx, farmId, input.date, input.scope === 'all' ? undefined : input.scope)).filter(
    (a) => a.free_x10 > 0,
  );
  const freeX10 = amrs.reduce((n, a) => n + a.free_x10, 0);
  if (freeX10 === 0) throw new AppError('NO_GROSS_MILK', 'There is no uncommitted milk for this session');
  const wantX10 = input.litres === undefined ? freeX10 : toX10(input.litres);
  if (wantX10 > freeX10) {
    throw new AppError('EXCEEDS_GROSS', 'Committed litres cannot exceed the milk recorded', {
      requestedLitres: wantX10 / 10, freeLitres: freeX10 / 10,
    });
  }

  // Take litres from AMRs in session and recording order.
  const parts: { amrId: string; session: Session; litresX10: number }[] = [];
  let left = wantX10;
  for (const a of amrs) {
    if (left === 0) break;
    const take = Math.min(a.free_x10, left);
    parts.push({ amrId: a.amr_id, session: a.session, litresX10: take });
    left -= take;
  }

  const farmLotId = newId('FL');
  const createdAt = now();
  const payload = {
    farmLotId, farmId, lotDate: input.date, scope: input.scope, committedX10: wantX10,
    amrs: parts.map((p) => ({ amrId: p.amrId, litresX10: p.litresX10 })),
    createdAt: createdAt.toISOString(), createdBy: actor.userId, channel: actor.channel,
  };
  const chainKey = chainKeys.farm(farmId);
  const link = await appendLink(tx, chainKey, 'farm_lot', farmLotId, payload);
  await tx.query(
    `INSERT INTO farm_lot(farm_lot_id, farm_id, lot_date, scope, committed_x10, created_at, created_by, channel, prev_hash, hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [farmLotId, farmId, input.date, input.scope, wantX10, createdAt, actor.userId, actor.channel, link.prevHash, link.hash],
  );
  for (const p of parts) {
    await tx.query(`INSERT INTO farm_lot_amr(farm_lot_id, amr_id, litres_x10) VALUES ($1,$2,$3)`, [
      farmLotId, p.amrId, p.litresX10,
    ]);
  }
  // Once any part of a session is committed, every AMR of that session is locked.
  const touched = [...new Set(parts.map((p) => p.session))];
  await tx.query(
    `UPDATE amr SET locked = true WHERE farm_id = $1 AND milk_date = $2 AND session = ANY($3) AND NOT locked`,
    [farmId, input.date, touched],
  );
  await writeTrail(tx, actor, {
    recordId: farmLotId, recordType: 'farm_lot', chainKey, event: 'created',
    fromStatus: null, toStatus: 'awaiting_collection', amount: wantX10, data: { lockedSessions: touched },
  });
  return (await getLots(tx, farmId, { farmLotId }))[0];
}

export async function withdrawFarmLot(tx: Tx, actor: Actor, farmId: string, farmLotId: string, reason?: string) {
  await authorize(actor, 'farm_lot.withdraw', { farmId });
  await lockFarm(tx, farmId);
  const r = await tx.query<{ status: string }>(
    `SELECT status FROM farm_lot WHERE farm_lot_id = $1 AND farm_id = $2 FOR UPDATE`,
    [farmLotId, farmId],
  );
  if (!r.rows[0]) throw new AppError('NOT_FOUND', 'Farm lot not found');
  if (r.rows[0].status !== 'awaiting_collection') {
    throw new AppError('LOT_NOT_WITHDRAWABLE', `A lot that is ${r.rows[0].status} cannot be withdrawn`);
  }
  await stepStatus(tx, actor, {
    table: 'farm_lot', idColumn: 'farm_lot_id', recordId: farmLotId, recordType: 'farm_lot',
    chainKey: chainKeys.farm(farmId), event: 'withdrawn', fromStatus: 'awaiting_collection', toStatus: 'withdrawn',
    reason: reason ?? null,
  });
  return (await getLots(tx, farmId, { farmLotId }))[0];
}

export async function listFarmLots(actor: Actor, farmId: string, date: string, db: Db = pool) {
  await authorize(actor, 'farm_lot.read', { farmId });
  return getLots(db, farmId, { date });
}

async function getLots(db: Db, farmId: string, by: { farmLotId?: string; date?: string }) {
  const lots = await db.query(
    `SELECT * FROM farm_lot WHERE farm_id = $1 AND ($2::text IS NULL OR farm_lot_id = $2)
        AND ($3::date IS NULL OR lot_date = $3) ORDER BY created_at, farm_lot_id`,
    [farmId, by.farmLotId ?? null, by.date ?? null],
  );
  if (lots.rows.length === 0) return [];
  const parts = await db.query<{ farm_lot_id: string; amr_id: string; litres_x10: number }>(
    `SELECT farm_lot_id, amr_id, litres_x10 FROM farm_lot_amr WHERE farm_lot_id = ANY($1) ORDER BY amr_id`,
    [lots.rows.map((l) => l.farm_lot_id)],
  );
  return lots.rows.map((l) => ({
    farmLotId: l.farm_lot_id,
    farmId: l.farm_id,
    date: l.lot_date,
    scope: l.scope,
    committedLitres: fromX10(l.committed_x10),
    status: l.status,
    flags: { held: l.flag_held, disputed: l.flag_disputed, rejected: l.flag_rejected },
    collectedAt: l.collected_at,
    collectedLitres: fromX10(l.collected_x10),
    varianceLitres: fromX10(l.variance_x10),
    grade: l.grade,
    collectionBatchId: l.collection_batch_id,
    receivingLotId: l.receiving_lot_id,
    invoiceId: l.invoice_id,
    amrs: parts.rows
      .filter((p) => p.farm_lot_id === l.farm_lot_id)
      .map((p) => ({ amrId: p.amr_id, litres: p.litres_x10 / 10 })),
    createdAt: l.created_at,
    channel: l.channel,
    prevHash: l.prev_hash,
    hash: l.hash,
  }));
}
