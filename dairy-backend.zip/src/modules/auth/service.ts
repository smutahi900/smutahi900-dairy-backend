import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool, type Tx } from '../../db/pool.js';
import { config } from '../../config.js';
import { AppError } from '../../lib/errors.js';
import { now } from '../../lib/clock.js';
import { normalisePhone } from '../../lib/phone.js';
import type { Actor } from '../../lib/actor.js';

const PIN_RE = /^\d{4}$/;

export async function hashPin(pin: string): Promise<string> {
  if (!PIN_RE.test(pin)) throw new AppError('VALIDATION_FAILED', 'PIN must be 4 digits');
  return bcrypt.hash(pin, 10);
}

/**
 * Check a PIN with lockout. Used by web sign-in and by USSD, so both
 * channels share the same attempt counter.
 */
export async function checkPin(phoneInput: string, pin: string): Promise<{ userId: string }> {
  const phone = normalisePhone(phoneInput);
  const r = await pool.query<{ user_id: string; pin_hash: string | null; failed_pin_count: number; locked_until: Date | null }>(
    `SELECT user_id, pin_hash, failed_pin_count, locked_until FROM app_user WHERE phone = $1`,
    [phone],
  );
  const u = r.rows[0];
  // Same answer for unknown phone and wrong PIN, so numbers cannot be probed.
  if (!u || !u.pin_hash) throw new AppError('PIN_INVALID', 'Phone or PIN is wrong');
  if (u.locked_until && u.locked_until > now()) {
    throw new AppError('PIN_LOCKED', 'Too many wrong PINs. Try again later');
  }
  const ok = PIN_RE.test(pin) && (await bcrypt.compare(pin, u.pin_hash));
  if (!ok) {
    const failed = u.failed_pin_count + 1;
    const lock = failed >= config.pinMaxAttempts ? new Date(now().getTime() + config.pinLockMinutes * 60_000) : null;
    await pool.query(`UPDATE app_user SET failed_pin_count = $2, locked_until = $3 WHERE user_id = $1`, [
      u.user_id, lock ? 0 : failed, lock,
    ]);
    throw new AppError(lock ? 'PIN_LOCKED' : 'PIN_INVALID', lock ? 'Too many wrong PINs. Try again later' : 'Phone or PIN is wrong');
  }
  if (u.failed_pin_count > 0 || u.locked_until) {
    await pool.query(`UPDATE app_user SET failed_pin_count = 0, locked_until = NULL WHERE user_id = $1`, [u.user_id]);
  }
  return { userId: u.user_id };
}

export function signToken(userId: string): string {
  return jwt.sign({ sub: userId }, config.jwtSecret, { expiresIn: config.tokenTtl } as jwt.SignOptions);
}

export function verifyToken(token: string): string {
  try {
    const p = jwt.verify(token, config.jwtSecret) as jwt.JwtPayload;
    if (typeof p.sub !== 'string') throw new Error('no sub');
    return p.sub;
  } catch {
    throw new AppError('UNAUTHENTICATED', 'Sign in again');
  }
}

export async function changePin(tx: Tx, actor: Actor, oldPin: string, newPin: string): Promise<void> {
  await checkPin(actor.phone, oldPin);
  await tx.query(`UPDATE app_user SET pin_hash = $2 WHERE user_id = $1`, [actor.userId, await hashPin(newPin)]);
}
