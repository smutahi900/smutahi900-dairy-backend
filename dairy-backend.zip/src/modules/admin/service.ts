import type { Tx } from '../../db/pool.js';
import type { Actor } from '../../lib/actor.js';
import { AppError } from '../../lib/errors.js';
import { newId, randomPin } from '../../lib/ids.js';
import { normalisePhone } from '../../lib/phone.js';
import { authorize, GRANTABLE, logAccess, ROLE_SCOPE, ROLES, type Role } from '../../lib/rbac.js';
import { queueSms } from '../../lib/sms.js';
import { hashPin } from '../auth/service.js';

export async function createCooperative(tx: Tx, actor: Actor, name: string) {
  await authorize(actor, 'cooperative.create');
  const coopId = newId('CO');
  await tx.query(`INSERT INTO cooperative(coop_id, name, created_by, channel) VALUES ($1,$2,$3,$4)`, [
    coopId, name, actor.userId, actor.channel,
  ]);
  return { coopId, name };
}

/**
 * Find a user by phone or create one. A new user gets a one-time PIN by SMS
 * and must change it after first sign-in.
 */
export async function findOrCreateUser(tx: Tx, actor: Actor, phoneInput: string, name: string) {
  const phone = normalisePhone(phoneInput);
  const found = await tx.query<{ user_id: string }>(`SELECT user_id FROM app_user WHERE phone = $1`, [phone]);
  if (found.rows[0]) return { userId: found.rows[0].user_id, phone, created: false };
  const userId = newId('US');
  const pin = randomPin();
  await tx.query(
    `INSERT INTO app_user(user_id, phone, name, pin_hash, created_by, channel) VALUES ($1,$2,$3,$4,$5,$6)`,
    [userId, phone, name, await hashPin(pin), actor.userId, actor.channel],
  );
  await queueSms(tx, phone, `Welcome to the dairy platform. Your PIN is ${pin}. Change it after you sign in`, 'welcome_pin', userId);
  return { userId, phone, created: true };
}

export interface GrantInput {
  userId: string;
  role: string;
  scopeId?: string | null;
}

function scopeTarget(scopeType: string, scopeId: string | null) {
  if (scopeType === 'cooperative') return { coopId: scopeId ?? '' };
  if (scopeType === 'farm') return { farmId: scopeId ?? '' };
  if (scopeType === 'vendor') return { vendorId: scopeId ?? '' };
  return {};
}

export async function grantRole(tx: Tx, actor: Actor, input: GrantInput, opts: { skipAuth?: boolean } = {}) {
  if (!ROLES.includes(input.role as Role)) throw new AppError('VALIDATION_FAILED', `Unknown role ${input.role}`);
  const role = input.role as Role;
  const scopeType = ROLE_SCOPE[role];
  const scopeId = scopeType === 'platform' ? null : (input.scopeId ?? null);
  if (scopeType !== 'platform' && !scopeId) throw new AppError('VALIDATION_FAILED', `${role} needs a ${scopeType} scope`);

  if (!opts.skipAuth) {
    // The granter must hold role.grant over the same scope, and be allowed to hand out this role.
    const via = await authorize(actor, 'role.grant', scopeTarget(scopeType, scopeId));
    if (!GRANTABLE[via.role as Role]?.includes(role)) {
      await logAccess(actor, 'role.grant', role, false, `${via.role} cannot grant ${role}`);
      throw new AppError('FORBIDDEN_ROLE', `A ${via.role} cannot grant ${role}`);
    }
  }
  const user = await tx.query(`SELECT 1 FROM app_user WHERE user_id = $1`, [input.userId]);
  if (!user.rows[0]) throw new AppError('NOT_FOUND', 'User not found');

  const existing = await tx.query<{ grant_id: string }>(
    `SELECT grant_id FROM role_grant WHERE user_id=$1 AND role=$2 AND scope_type=$3
       AND coalesce(scope_id,'') = coalesce($4,'') AND revoked_at IS NULL`,
    [input.userId, role, scopeType, scopeId],
  );
  if (existing.rows[0]) return { grantId: existing.rows[0].grant_id, userId: input.userId, role, scopeType, scopeId };

  const grantId = newId('RG');
  await tx.query(
    `INSERT INTO role_grant(grant_id, user_id, role, scope_type, scope_id, granted_by) VALUES ($1,$2,$3,$4,$5,$6)`,
    [grantId, input.userId, role, scopeType, scopeId, actor.userId],
  );
  await tx.query(
    `INSERT INTO access_log(user_id, channel, action, resource, allowed, reason) VALUES ($1,$2,'role.granted',$3,true,$4)`,
    [actor.userId, actor.channel, grantId, `${role} ${scopeType}:${scopeId ?? '*'} to ${input.userId}`],
  );
  return { grantId, userId: input.userId, role, scopeType, scopeId };
}

export async function revokeRole(tx: Tx, actor: Actor, grantId: string) {
  const g = await tx.query<{ role: Role; scope_type: string; scope_id: string | null; user_id: string }>(
    `SELECT role, scope_type, scope_id, user_id FROM role_grant WHERE grant_id = $1 AND revoked_at IS NULL FOR UPDATE`,
    [grantId],
  );
  const grant = g.rows[0];
  if (!grant) throw new AppError('NOT_FOUND', 'Active grant not found');
  const via = await authorize(actor, 'role.revoke', scopeTarget(grant.scope_type, grant.scope_id));
  if (!GRANTABLE[via.role as Role]?.includes(grant.role)) {
    await logAccess(actor, 'role.revoke', grantId, false, `${via.role} cannot revoke ${grant.role}`);
    throw new AppError('FORBIDDEN_ROLE', `A ${via.role} cannot revoke ${grant.role}`);
  }
  await tx.query(`UPDATE role_grant SET revoked_at = now(), revoked_by = $2 WHERE grant_id = $1`, [grantId, actor.userId]);
  await tx.query(
    `INSERT INTO access_log(user_id, channel, action, resource, allowed, reason) VALUES ($1,$2,'role.revoked',$3,true,$4)`,
    [actor.userId, actor.channel, grantId, `${grant.role} from ${grant.user_id}`],
  );
  return { grantId, revoked: true };
}
