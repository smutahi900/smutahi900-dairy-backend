/**
 * USSD menu for farmers. The gateway (Africa's Talking style) posts the whole
 * input history each hop, e.g. text = "1234*1*2*3*12.5". The menu is
 * replayed from that history, so the server keeps no menu state; only the
 * PIN result is cached per session (ussd_session).
 *
 * Replies start with "CON " (ask for more) or "END " (close the session).
 * Menu numbers have no full stop after them ("1 Record milk").
 *
 * ASSUMPTION: menu wording is a first draft. Replace it with the texts in
 * the USSD Developer Reference.
 */
import { pool } from '../../db/pool.js';
import { loadActor, type Actor } from '../../lib/actor.js';
import { now, todayNairobi } from '../../lib/clock.js';
import { config } from '../../config.js';
import { AppError } from '../../lib/errors.js';
import { idempotentWrite } from '../../lib/idempotency.js';
import { normalisePhone } from '../../lib/phone.js';
import { checkPin } from '../auth/service.js';
import * as farmer from '../farmer/service.js';

const SESSION_MINUTES = 5;
const PAGE_SIZE = 6;
const MORE = '98';

class Reply {
  constructor(readonly text: string) {}
}
const con = (s: string) => new Reply(`CON ${s}`);
const end = (s: string) => new Reply(`END ${s}`);

class Cursor {
  private i = 0;
  constructor(private readonly inputs: string[]) {}
  has() {
    return this.i < this.inputs.length;
  }
  next() {
    return this.inputs[this.i++].trim();
  }
}

/** Ask until a valid answer is given. An invalid answer re-shows the prompt. */
function ask<T>(c: Cursor, prompt: string, parseInput: (v: string) => T | undefined): T {
  let invalid = false;
  for (;;) {
    if (!c.has()) throw con(`${invalid ? 'Invalid entry\n' : ''}${prompt}`);
    const v = parseInput(c.next());
    if (v !== undefined) return v;
    invalid = true;
  }
}

/** Numbered choice with paging ("98 More"). */
function choose<T>(c: Cursor, title: string, options: { label: string; value: T }[]): T {
  let page = 0;
  let invalid = false;
  for (;;) {
    const start = page * PAGE_SIZE;
    const shown = options.slice(start, start + PAGE_SIZE);
    const hasMore = start + PAGE_SIZE < options.length;
    const lines = shown.map((o, k) => `${start + k + 1} ${o.label}`);
    if (hasMore) lines.push(`${MORE} More`);
    if (!c.has()) throw con(`${invalid ? 'Invalid entry\n' : ''}${title}\n${lines.join('\n')}`);
    const v = c.next();
    if (v === MORE && hasMore) {
      page++;
      invalid = false;
      continue;
    }
    const n = Number(v);
    if (Number.isInteger(n) && n >= 1 && n <= options.length) return options[n - 1].value;
    invalid = true;
  }
}

function yesNo(c: Cursor, prompt: string): boolean {
  return choose(c, prompt, [
    { label: 'Yes', value: true },
    { label: 'No', value: false },
  ]);
}

const SESSION_LABEL: Record<farmer.Session, string> = { morning: 'Morning', afternoon: 'Afternoon', evening: 'Evening' };
const fmtL = (n: number) => `${n.toFixed(1)} L`;

/** Short texts for error codes. Codes are the same as the web API. */
const USSD_MESSAGES: Record<string, string> = {
  RECORD_LOCKED: 'That session is committed and locked',
  NO_GROSS_MILK: 'No uncommitted milk for that session',
  EXCEEDS_GROSS: 'More than the milk recorded',
  NOT_TODAY: 'Only today\'s milk can be committed',
  LOT_NOT_WITHDRAWABLE: 'That lot can no longer be withdrawn',
  FORBIDDEN_ROLE: 'You are not allowed to do this',
  PIN_INVALID: 'Wrong PIN',
  PIN_LOCKED: 'Too many wrong PINs. Try again later',
  ANIMAL_NOT_FOUND: 'Animal not found',
  VALIDATION_FAILED: 'Invalid entry',
};

export interface UssdRequest {
  sessionId: string;
  phoneNumber: string;
  text: string;
}

export async function handleUssd(req: UssdRequest): Promise<string> {
  try {
    await run(req);
    return 'END Goodbye';
  } catch (e) {
    if (e instanceof Reply) return e.text;
    if (e instanceof AppError) return `END ${USSD_MESSAGES[e.code] ?? e.message} (${e.code})`;
    console.error('ussd error', e);
    return 'END Service error. Please try again';
  }
}

async function run(req: UssdRequest): Promise<void> {
  let phone: string;
  try {
    phone = normalisePhone(req.phoneNumber);
  } catch {
    throw end('This number cannot use the service');
  }
  const inputs = req.text === '' ? [] : req.text.split('*');
  const c = new Cursor(inputs);

  const actor = await signIn(c, req.sessionId, phone);
  const farms = await farmer.farmsOfFarmer(actor);
  if (farms.length === 0) throw end('This number is not registered as a farmer. Visit your cooperative');
  const farmId = farms.length === 1 ? farms[0] : choose(c, 'Choose farm', farms.map((f) => ({ label: f, value: f })));

  const action = choose(c, 'Dairy menu', [
    { label: 'Record milk', value: 'record' as const },
    { label: 'Commit milk', value: 'commit' as const },
    { label: 'Today\'s milk', value: 'today' as const },
    { label: 'Withdraw a lot', value: 'withdraw' as const },
  ]);
  const write = <T>(name: string, body: unknown, fn: Parameters<typeof idempotentWrite<T>>[4]) =>
    // A resent final hop has the same session and text, so it returns the first result.
    idempotentWrite(actor, `ussd:${req.sessionId}:${req.text}`, name, body, fn);

  if (action === 'record') {
    const animals = await farmer.listAnimals(actor, farmId);
    if (animals.length === 0) throw end('No animals on this farm. Ask your cooperative to add them');
    const animal = choose(c, 'Choose animal', animals.map((a) => ({ label: a.name ? `${a.tag} ${a.name}` : a.tag, value: a })));
    const session = choose(c, 'Session', farmer.SESSIONS.map((s) => ({ label: SESSION_LABEL[s], value: s })));
    const litres = ask(c, 'Enter litres', (v) => {
      const n = Number(v);
      return /^\d+(\.\d)?$/.test(v) && n > 0 ? n : undefined;
    });
    let confirmLarge = false;
    if (litres > config.amrConfirmAboveLitres) {
      confirmLarge = yesNo(c, `${fmtL(litres)} is more than ${config.amrConfirmAboveLitres} L. Is it correct`);
      if (!confirmLarge) throw end('Not saved');
    }
    if (!yesNo(c, `Save ${animal.tag}, ${SESSION_LABEL[session]}, ${fmtL(litres)}`)) throw end('Not saved');
    const body = { milkDate: todayNairobi(), session, animalId: animal.animalId, litres, confirmLarge };
    const r = await write('amr.create', { farmId, ...body }, async (tx) => ({
      status: 201, body: await farmer.recordAmr(tx, actor, farmId, body),
    }));
    const amr = r.body as Awaited<ReturnType<typeof farmer.recordAmr>>;
    throw end(`Saved ${fmtL(amr.litres)} for ${animal.tag}, ${SESSION_LABEL[session]}`);
  }

  if (action === 'commit') {
    const scope = choose(c, 'Commit which milk', [
      ...farmer.SESSIONS.map((s) => ({ label: SESSION_LABEL[s], value: s as farmer.LotScope })),
      { label: 'All today', value: 'all' as farmer.LotScope },
    ]);
    const date = todayNairobi();
    const s = await farmer.milkSessions(actor, farmId, date);
    const free = scope === 'all' ? s.total.freeLitres : s.sessions.find((x) => x.session === scope)!.freeLitres;
    if (free === 0) throw end(USSD_MESSAGES.NO_GROSS_MILK);
    const label = scope === 'all' ? 'all today\'s' : SESSION_LABEL[scope].toLowerCase();
    if (!yesNo(c, `Commit ${fmtL(free)} of ${label} milk`)) throw end('Not committed');
    // The litres shown are sent, so a change in between is caught as EXCEEDS_GROSS.
    const body = { date, scope, litres: free };
    const r = await write('farm_lot.create', { farmId, ...body }, async (tx) => ({
      status: 201, body: await farmer.commitFarmLot(tx, actor, farmId, body),
    }));
    const lot = r.body as Awaited<ReturnType<typeof farmer.commitFarmLot>>;
    throw end(`Committed ${lot.farmLotId}, ${fmtL(lot.committedLitres!)}. Awaiting collection`);
  }

  if (action === 'today') {
    const date = todayNairobi();
    const s = await farmer.milkSessions(actor, farmId, date);
    const lots = await farmer.listFarmLots(actor, farmId, date);
    const lines = s.sessions
      .filter((x) => x.records > 0)
      .map((x) => `${SESSION_LABEL[x.session]} ${fmtL(x.grossLitres)}, free ${fmtL(x.freeLitres)}`);
    for (const l of lots) lines.push(`${l.farmLotId} ${fmtL(l.committedLitres!)} ${l.status.replace(/_/g, ' ')}`);
    throw end(lines.length ? `Today\n${lines.join('\n')}` : 'No milk recorded today');
  }

  // withdraw
  const lots = (await farmer.listFarmLots(actor, farmId, todayNairobi())).filter((l) => l.status === 'awaiting_collection');
  if (lots.length === 0) throw end('No lots awaiting collection');
  const lot = choose(c, 'Withdraw which lot', lots.map((l) => ({ label: `${l.farmLotId} ${fmtL(l.committedLitres!)}`, value: l })));
  if (!yesNo(c, `Withdraw ${lot.farmLotId}`)) throw end('Not withdrawn');
  await write('farm_lot.withdraw', { farmId, farmLotId: lot.farmLotId }, async (tx) => ({
    status: 200, body: await farmer.withdrawFarmLot(tx, actor, farmId, lot.farmLotId, 'withdrawn on USSD'),
  }));
  throw end(`${lot.farmLotId} withdrawn`);
}

async function signIn(c: Cursor, sessionId: string, phone: string): Promise<Actor> {
  const user = await pool.query<{ user_id: string }>(`SELECT user_id FROM app_user WHERE phone = $1`, [phone]);
  if (!user.rows[0]) throw end('This number is not registered. Visit your cooperative');
  const userId = user.rows[0].user_id;

  const s = await pool.query<{ phone: string; pin_ok_at: Date | null; started_at: Date }>(
    `SELECT phone, pin_ok_at, started_at FROM ussd_session WHERE session_id = $1`,
    [sessionId],
  );
  const fresh = (d: Date) => now().getTime() - d.getTime() < SESSION_MINUTES * 60_000;
  const cached = s.rows[0];
  if (cached && cached.phone !== phone) throw end('Session error. Please dial again');

  if (!c.has()) {
    await pool.query(
      `INSERT INTO ussd_session(session_id, phone, user_id, started_at) VALUES ($1,$2,$3,$4) ON CONFLICT (session_id) DO NOTHING`,
      [sessionId, phone, userId, now()],
    );
    throw con('Welcome\nEnter your PIN');
  }
  const pin = c.next();
  if (!(cached?.pin_ok_at && fresh(cached.pin_ok_at))) {
    if (cached && !fresh(cached.started_at)) throw end('Session expired. Please dial again');
    await checkPin(phone, pin); // throws PIN_INVALID / PIN_LOCKED -> END
    await pool.query(
      `INSERT INTO ussd_session(session_id, phone, user_id, pin_ok_at, started_at) VALUES ($1,$2,$3,$4,$4)
       ON CONFLICT (session_id) DO UPDATE SET pin_ok_at = $4`,
      [sessionId, phone, userId, now()],
    );
  }
  const actor = await loadActor(userId, 'ussd');
  if (!actor) throw end('This number is not registered');
  return actor;
}
