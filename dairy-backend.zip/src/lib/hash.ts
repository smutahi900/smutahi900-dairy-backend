import { createHash } from 'node:crypto';

/** Canonical JSON: object keys sorted, no whitespace. Same input, same string, same hash. */
export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value ?? null);
  if (value instanceof Date) return JSON.stringify(value.toISOString());
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj).filter((k) => obj[k] !== undefined).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(obj[k])}`).join(',')}}`;
}

export function sha256(s: string): string {
  return createHash('sha256').update(s).digest('hex');
}

export const GENESIS_HASH = '0'.repeat(64);

/** hash = SHA-256(canonical JSON + prevHash), as in brief section 5. */
export function linkHash(payload: unknown, prevHash: string): string {
  return sha256(canonicalJson(payload) + prevHash);
}
