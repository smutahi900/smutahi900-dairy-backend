/**
 * Error codes are the same on every channel (web, app, USSD).
 * HTTP statuses follow the brief where it gives one; the rest are marked
 * "chosen" and should be confirmed (brief section 6).
 */
export const ERROR_STATUS: Record<string, number> = {
  // foundation
  VALIDATION_FAILED: 422,
  UNAUTHENTICATED: 401,
  PIN_INVALID: 401,
  PIN_LOCKED: 423, // chosen
  FORBIDDEN_ROLE: 403, // brief
  NOT_FOUND: 404,
  IDEMPOTENCY_KEY_REQUIRED: 400, // chosen
  IDEMPOTENCY_KEY_REUSED: 422, // chosen: same key, different body
  RECORD_LOCKED: 405, // brief
  PHONE_IN_USE: 409, // chosen
  // farmer
  CONFIRMATION_REQUIRED: 422, // chosen: AMR above 500 L
  DATE_IN_FUTURE: 422, // chosen
  ANIMAL_NOT_FOUND: 404,
  FARM_NOT_FOUND: 404,
  EXCEEDS_GROSS: 422, // chosen
  NO_GROSS_MILK: 422, // chosen
  NOT_TODAY: 422, // chosen
  LOT_NOT_WITHDRAWABLE: 409, // chosen
};

export class AppError extends Error {
  readonly status: number;
  constructor(
    readonly code: string,
    message?: string,
    readonly details?: unknown,
  ) {
    super(message ?? code);
    this.status = ERROR_STATUS[code] ?? 400;
  }
}

export function toErrorBody(err: AppError) {
  return { error: { code: err.code, message: err.message, ...(err.details ? { details: err.details } : {}) } };
}
