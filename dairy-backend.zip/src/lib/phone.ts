import { AppError } from './errors.js';

/** Normalise Kenyan numbers to E.164: 0712..., 712..., 254712..., +254712... -> +254712... */
export function normalisePhone(input: string): string {
  const digits = input.replace(/[\s-]/g, '');
  let m: RegExpMatchArray | null;
  if ((m = digits.match(/^\+?254([17]\d{8})$/))) return `+254${m[1]}`;
  if ((m = digits.match(/^0([17]\d{8})$/))) return `+254${m[1]}`;
  if ((m = digits.match(/^([17]\d{8})$/))) return `+254${m[1]}`;
  throw new AppError('VALIDATION_FAILED', 'phone must be a Kenyan mobile number');
}
