import type { Tx } from '../db/pool.js';
import type { Actor } from './actor.js';
import { appendLink } from './chain.js';
import { now } from './clock.js';
import { newId } from './ids.js';

export interface TrailInput {
  recordId: string;
  recordType: string;
  chainKey: string;
  event: string;
  fromStatus?: string | null;
  toStatus?: string | null;
  amount?: number | null;
  reference?: string | null;
  reason?: string | null;
  data?: Record<string, unknown> | null;
}

/** Every status step writes one hashed line: who, when, from status, to status. */
export async function writeTrail(tx: Tx, actor: Actor, t: TrailInput): Promise<string> {
  const eventId = newId('TE', 10);
  const at = now();
  const payload = {
    eventId,
    recordId: t.recordId,
    recordType: t.recordType,
    event: t.event,
    actor: actor.userId,
    channel: actor.channel,
    at: at.toISOString(),
    fromStatus: t.fromStatus ?? null,
    toStatus: t.toStatus ?? null,
    amount: t.amount ?? null,
    reference: t.reference ?? null,
    reason: t.reason ?? null,
    data: t.data ?? null,
  };
  const link = await appendLink(tx, t.chainKey, 'trail_event', eventId, payload);
  await tx.query(
    `INSERT INTO trail_event(event_id, record_id, record_type, event, actor, channel, at, from_status, to_status,
       amount, reference, reason, data, prev_hash, hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
    [eventId, t.recordId, t.recordType, t.event, actor.userId, actor.channel, at, payload.fromStatus,
      payload.toStatus, payload.amount, payload.reference, payload.reason, t.data ?? null, link.prevHash, link.hash],
  );
  return eventId;
}

/** Status step on a record: the caller has already checked the move is allowed. */
export async function stepStatus(
  tx: Tx,
  actor: Actor,
  t: TrailInput & { table: string; idColumn: string; fromStatus: string; toStatus: string },
): Promise<void> {
  const r = await tx.query(
    `UPDATE ${t.table} SET status = $3 WHERE ${t.idColumn} = $1 AND status = $2`,
    [t.recordId, t.fromStatus, t.toStatus],
  );
  if (r.rowCount !== 1) throw new Error(`status step ${t.fromStatus} -> ${t.toStatus} lost a race on ${t.recordId}`);
  await writeTrail(tx, actor, t);
}
