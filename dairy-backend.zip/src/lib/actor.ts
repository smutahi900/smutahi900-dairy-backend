import type { Tx } from '../db/pool.js';
import { pool } from '../db/pool.js';

export type Channel = 'app' | 'web' | 'ussd' | 'system';

export interface Grant {
  grantId: string;
  role: string;
  scopeType: string;
  scopeId: string | null;
}

export interface Actor {
  userId: string;
  phone: string;
  name: string;
  channel: Channel;
  grants: Grant[];
  deviceId?: string;
}

export async function loadActor(userId: string, channel: Channel, db: Pick<Tx, 'query'> = pool): Promise<Actor | null> {
  const u = await db.query<{ user_id: string; phone: string; name: string }>(
    `SELECT user_id, phone, name FROM app_user WHERE user_id = $1`,
    [userId],
  );
  if (!u.rows[0]) return null;
  const g = await db.query<{ grant_id: string; role: string; scope_type: string; scope_id: string | null }>(
    `SELECT grant_id, role, scope_type, scope_id FROM role_grant WHERE user_id = $1 AND revoked_at IS NULL`,
    [userId],
  );
  return {
    userId: u.rows[0].user_id,
    phone: u.rows[0].phone,
    name: u.rows[0].name,
    channel,
    grants: g.rows.map((r) => ({ grantId: r.grant_id, role: r.role, scopeType: r.scope_type, scopeId: r.scope_id })),
  };
}

/** The back end's own actor, used by jobs (daily root, SMS worker). */
export const SYSTEM_ACTOR: Actor = { userId: 'SYSTEM', phone: '', name: 'System', channel: 'system', grants: [] };
