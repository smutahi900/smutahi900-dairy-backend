import { AppError } from './errors.js';

/** Litres are kept to one decimal. Stored as integer tenths to avoid float drift. */
export function toX10(litres: number, field = 'litres'): number {
  if (typeof litres !== 'number' || !Number.isFinite(litres) || litres <= 0) {
    throw new AppError('VALIDATION_FAILED', `${field} must be a positive number`);
  }
  const x10 = Math.round(litres * 10);
  if (Math.abs(x10 - litres * 10) > 1e-6) {
    throw new AppError('VALIDATION_FAILED', `${field} may have at most one decimal place`);
  }
  return x10;
}

export function fromX10(x10: number | null): number | null {
  return x10 === null ? null : x10 / 10;
}
