import { withTx, type Tx } from '../db/pool.js';
import type { Actor } from './actor.js';
import { AppError } from './errors.js';
import { canonicalJson, sha256 } from './hash.js';

export interface WriteResult<T = unknown> {
  status: number;
  body: T;
  replayed?: boolean;
}

/**
 * Every write carries an Idempotency-Key. The key row is inserted first in
 * the same transaction as the write: a concurrent retry with the same key
 * waits on the unique index, then reads the stored response. If the write
 * fails, the key is rolled back with it and a retry runs again.
 */
export async function idempotentWrite<T>(
  actor: Actor,
  key: string | undefined,
  action: string,
  request: unknown,
  fn: (tx: Tx) => Promise<WriteResult<T>>,
): Promise<WriteResult<T>> {
  if (!key) throw new AppError('IDEMPOTENCY_KEY_REQUIRED', 'Idempotency-Key header is required on every write');
  if (key.length > 200) throw new AppError('VALIDATION_FAILED', 'Idempotency-Key is too long');
  const requestHash = sha256(canonicalJson({ action, request }));

  return withTx(async (tx) => {
    const ins = await tx.query(
      `INSERT INTO idempotency_key(actor_id, key, action, request_hash) VALUES ($1,$2,$3,$4)
       ON CONFLICT DO NOTHING RETURNING key`,
      [actor.userId, key, action, requestHash],
    );
    if (ins.rowCount === 0) {
      const prev = await tx.query<{ request_hash: string; response_status: number; response_body: T }>(
        `SELECT request_hash, response_status, response_body FROM idempotency_key WHERE actor_id = $1 AND key = $2`,
        [actor.userId, key],
      );
      if (prev.rows[0].request_hash !== requestHash) {
        throw new AppError('IDEMPOTENCY_KEY_REUSED', 'This Idempotency-Key was used for a different request');
      }
      return { status: prev.rows[0].response_status, body: prev.rows[0].response_body, replayed: true };
    }
    const result = await fn(tx);
    await tx.query(
      `UPDATE idempotency_key SET response_status = $3, response_body = $4 WHERE actor_id = $1 AND key = $2`,
      [actor.userId, key, result.status, JSON.stringify(result.body)],
    );
    return result;
  });
}
