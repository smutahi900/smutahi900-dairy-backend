import { config } from '../config.js';

let override: (() => Date) | null = null;

export function now(): Date {
  return override ? override() : new Date();
}

/** Tests only: freeze or move the clock. */
export function setClock(fn: (() => Date) | null): void {
  override = fn;
}

/** Calendar date (YYYY-MM-DD) in Africa/Nairobi for the given instant. */
export function nairobiDate(d: Date = now()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: config.timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(d);
  return parts; // en-CA formats as YYYY-MM-DD
}

export function todayNairobi(): string {
  return nairobiDate(now());
}
