import type { Tx } from '../db/pool.js';
import { pool } from '../db/pool.js';
import type { Actor, Grant } from './actor.js';
import { AppError } from './errors.js';

/**
 * Register D33: 12 roles, deny by default, scope rule, permissions per role.
 *
 * ASSUMPTION: the brief says 12 roles but the names are in the Roles and
 * Access document, which this build did not have. The list below is a
 * placeholder to reconcile with that document; only names change, not the
 * mechanism.
 */
export const ROLE_SCOPE = {
  farmer: 'farm',
  collector: 'cooperative',
  cooperative_owner: 'cooperative',
  cooperative_clerk: 'cooperative',
  payment_initiator: 'cooperative',
  payment_approver: 'cooperative',
  processor: 'cooperative',
  transporter: 'cooperative',
  vendor: 'vendor',
  consumer: 'platform',
  regulator: 'platform',
  platform_admin: 'platform',
} as const;

export type Role = keyof typeof ROLE_SCOPE;
export const ROLES = Object.keys(ROLE_SCOPE) as Role[];

/** Action -> roles allowed. An action missing here is refused for everyone. */
export const PERMISSIONS: Record<string, Role[]> = {
  'cooperative.create': ['platform_admin'],
  'farm.create': ['cooperative_owner', 'cooperative_clerk', 'platform_admin'],
  'farm.read': ['farmer', 'cooperative_owner', 'cooperative_clerk', 'collector', 'regulator', 'platform_admin'],
  'animal.create': ['farmer', 'cooperative_owner', 'cooperative_clerk'],
  'animal.read': ['farmer', 'cooperative_owner', 'cooperative_clerk', 'regulator'],
  'amr.create': ['farmer'],
  'amr.read': ['farmer', 'cooperative_owner', 'cooperative_clerk', 'regulator'],
  'farm_lot.create': ['farmer'],
  'farm_lot.read': ['farmer', 'cooperative_owner', 'cooperative_clerk', 'collector', 'regulator'],
  'farm_lot.withdraw': ['farmer'],
  'role.grant': ['platform_admin', 'regulator', 'cooperative_owner'],
  'role.revoke': ['platform_admin', 'regulator', 'cooperative_owner'],
  'regulator.read': ['regulator'],
};

/** Which roles a granting role may hand out (and where). */
export const GRANTABLE: Partial<Record<Role, Role[]>> = {
  platform_admin: ROLES,
  // The KDB Managing Director is the first regulator and onboards the rest.
  regulator: ['regulator'],
  cooperative_owner: [
    'cooperative_owner', 'cooperative_clerk', 'collector', 'payment_initiator',
    'payment_approver', 'processor', 'transporter', 'farmer',
  ],
};

export interface Target {
  farmId?: string;
  coopId?: string;
  vendorId?: string;
}

async function coopOfFarm(farmId: string): Promise<string | null> {
  const r = await pool.query<{ coop_id: string }>(`SELECT coop_id FROM farm WHERE farm_id = $1`, [farmId]);
  return r.rows[0]?.coop_id ?? null;
}

function scopeMatches(g: Grant, t: Target & { farmCoopId?: string | null }): boolean {
  switch (g.scopeType) {
    case 'platform':
      return true;
    case 'farm':
      return t.farmId !== undefined && g.scopeId === t.farmId;
    case 'cooperative':
      if (t.coopId !== undefined) return g.scopeId === t.coopId;
      if (t.farmId !== undefined) return t.farmCoopId != null && g.scopeId === t.farmCoopId;
      return false;
    case 'vendor':
      return t.vendorId !== undefined && g.scopeId === t.vendorId;
    default:
      return false;
  }
}

/** Written outside the request transaction, so a refusal is logged even though the request rolls back. */
export async function logAccess(
  actor: Actor | null,
  action: string,
  resource: string | null,
  allowed: boolean,
  reason?: string,
): Promise<void> {
  await pool.query(
    `INSERT INTO access_log(user_id, channel, action, resource, allowed, reason) VALUES ($1,$2,$3,$4,$5,$6)`,
    [actor?.userId ?? null, actor?.channel ?? null, action, resource, allowed, reason ?? null],
  );
}

/** Deny by default. Returns the grant that allowed the call, or throws FORBIDDEN_ROLE. */
export async function authorize(actor: Actor, action: string, target: Target = {}): Promise<Grant> {
  const roles = PERMISSIONS[action] ?? [];
  const candidates = actor.grants.filter((g) => roles.includes(g.role as Role));
  if (candidates.length > 0) {
    const farmCoopId =
      target.farmId !== undefined && target.coopId === undefined && candidates.some((g) => g.scopeType === 'cooperative')
        ? await coopOfFarm(target.farmId)
        : undefined;
    const grant = candidates.find((g) => scopeMatches(g, { ...target, farmCoopId }));
    if (grant) return grant;
  }
  const resource = target.farmId ?? target.coopId ?? target.vendorId ?? null;
  await logAccess(actor, action, resource, false, candidates.length ? 'out of scope' : 'role not permitted');
  throw new AppError('FORBIDDEN_ROLE', `Not allowed: ${action}`);
}

export function hasRole(actor: Actor, role: Role): boolean {
  return actor.grants.some((g) => g.role === role);
}

export type { Tx };
