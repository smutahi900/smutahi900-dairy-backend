import type { Tx } from '../db/pool.js';
import { newId } from './ids.js';

/** Queue a message. Only the back end sends SMS; the provider worker drains the outbox. */
export async function queueSms(tx: Tx, phone: string, body: string, purpose: string, recordId?: string): Promise<string> {
  const smsId = newId('SM', 10);
  await tx.query(`INSERT INTO sms_outbox(sms_id, phone, body, purpose, record_id) VALUES ($1,$2,$3,$4,$5)`, [
    smsId, phone, body, purpose, recordId ?? null,
  ]);
  return smsId;
}
