import type { Tx } from '../db/pool.js';
import { GENESIS_HASH, linkHash } from './hash.js';
import { now } from './clock.js';

/** Chain keys: per farm for farm and collection records, per batch for batch events. */
export const chainKeys = {
  farm: (farmId: string) => `farm:${farmId}`,
  batch: (batchId: string) => `batch:${batchId}`,
  platform: () => 'platform',
};

export interface Link {
  seq: number;
  prevHash: string;
  hash: string;
}

/**
 * Append one link to a chain. The chain head row is locked for the rest of
 * the transaction, so two writers on the same chain are serialised.
 */
export async function appendLink(
  tx: Tx,
  chainKey: string,
  recordType: string,
  recordId: string,
  payload: Record<string, unknown>,
): Promise<Link> {
  await tx.query(
    `INSERT INTO chain_head(chain_key, seq, last_hash) VALUES ($1, 0, $2) ON CONFLICT DO NOTHING`,
    [chainKey, GENESIS_HASH],
  );
  const head = await tx.query<{ seq: number; last_hash: string }>(
    `SELECT seq, last_hash FROM chain_head WHERE chain_key = $1 FOR UPDATE`,
    [chainKey],
  );
  const prevHash = head.rows[0].last_hash;
  const seq = head.rows[0].seq + 1;
  const hash = linkHash(payload, prevHash);
  await tx.query(
    `INSERT INTO chain_link(chain_key, seq, record_type, record_id, prev_hash, hash, payload, at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [chainKey, seq, recordType, recordId, prevHash, hash, payload, now()],
  );
  await tx.query(`UPDATE chain_head SET seq = $2, last_hash = $3 WHERE chain_key = $1`, [chainKey, seq, hash]);
  return { seq, prevHash, hash };
}

export interface ChainCheck {
  chainKey: string;
  links: number;
  valid: boolean;
  brokenAt?: { seq: number; recordId: string; problem: string };
}

const RECORD_TABLES: Record<string, { table: string; idColumn: string }> = {
  farm: { table: 'farm', idColumn: 'farm_id' },
  amr: { table: 'amr', idColumn: 'amr_id' },
  farm_lot: { table: 'farm_lot', idColumn: 'farm_lot_id' },
  trail_event: { table: 'trail_event', idColumn: 'event_id' },
  correction: { table: 'correction', idColumn: 'correction_id' },
};

/** Recompute every link of a chain and compare with the hash stored on each record. */
export async function verifyChain(db: Tx | { query: Tx['query'] }, chainKey: string): Promise<ChainCheck> {
  const { rows } = await db.query<{
    seq: number; record_type: string; record_id: string; prev_hash: string; hash: string; payload: Record<string, unknown>;
  }>(`SELECT seq, record_type, record_id, prev_hash, hash, payload FROM chain_link WHERE chain_key = $1 ORDER BY seq`, [
    chainKey,
  ]);
  let expectedPrev = GENESIS_HASH;
  for (const [i, link] of rows.entries()) {
    const fail = (problem: string): ChainCheck => ({
      chainKey, links: rows.length, valid: false, brokenAt: { seq: link.seq, recordId: link.record_id, problem },
    });
    if (link.seq !== i + 1) return fail('sequence gap');
    if (link.prev_hash !== expectedPrev) return fail('prevHash does not match the previous link');
    if (linkHash(link.payload, link.prev_hash) !== link.hash) return fail('hash does not match payload');
    const t = RECORD_TABLES[link.record_type];
    if (t) {
      const r = await db.query<{ hash: string }>(`SELECT hash FROM ${t.table} WHERE ${t.idColumn} = $1`, [link.record_id]);
      if (r.rows[0]?.hash !== link.hash) return fail('record hash differs from chain');
    }
    expectedPrev = link.hash;
  }
  return { chainKey, links: rows.length, valid: true };
}
