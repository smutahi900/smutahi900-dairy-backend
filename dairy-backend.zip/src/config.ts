function required(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined || v === '') throw new Error(`Missing environment variable ${name}`);
  return v;
}

const isTest = process.env.NODE_ENV === 'test';

export const config = {
  databaseUrl: required(
    'DATABASE_URL',
    isTest ? 'postgres://dairy:dairy@localhost:5432/dairy_test' : undefined,
  ),
  port: Number(process.env.PORT ?? 3000),
  jwtSecret: required('JWT_SECRET', isTest ? 'test-secret' : undefined),
  ussdGatewayKey: required('USSD_GATEWAY_KEY', isTest ? 'test-ussd-key' : undefined),
  timezone: 'Africa/Nairobi',
  /** Above this many litres an AMR needs an explicit confirmation. */
  amrConfirmAboveLitres: 500,
  pinMaxAttempts: 5,
  pinLockMinutes: 15,
  tokenTtl: '12h',
};
