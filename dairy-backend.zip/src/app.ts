import Fastify, { type FastifyReply, type FastifyRequest } from 'fastify';
import formbody from '@fastify/formbody';
import { z } from 'zod';
import { loadActor, type Actor, type Channel } from './lib/actor.js';
import { AppError, toErrorBody } from './lib/errors.js';
import { idempotentWrite, type WriteResult } from './lib/idempotency.js';
import { parse } from './lib/validate.js';
import type { Tx } from './db/pool.js';
import { withTx } from './db/pool.js';
import { config } from './config.js';
import { changePin, checkPin, signToken, verifyToken } from './modules/auth/service.js';
import * as admin from './modules/admin/service.js';
import * as farmer from './modules/farmer/service.js';
import * as regulator from './modules/regulator/service.js';
import { handleUssd } from './modules/ussd/menu.js';
import { todayNairobi } from './lib/clock.js';

declare module 'fastify' {
  interface FastifyRequest {
    actor?: Actor;
  }
}

const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'date must be YYYY-MM-DD');
const session = z.enum(['morning', 'afternoon', 'evening']);

/** ?date=today or ?date=YYYY-MM-DD */
function dateParam(q: unknown): string {
  const d = (q as { date?: string })?.date ?? 'today';
  return d === 'today' ? todayNairobi() : parse(date, d);
}

function channelOf(req: FastifyRequest): Channel {
  const c = req.headers['x-client-channel'];
  return c === 'app' ? 'app' : 'web';
}

function actorOf(req: FastifyRequest): Actor {
  if (!req.actor) throw new AppError('UNAUTHENTICATED', 'Sign in first');
  return req.actor;
}

/** Run a write with the Idempotency-Key header and send the stored or new result. */
async function write<T>(
  req: FastifyRequest,
  reply: FastifyReply,
  action: string,
  fn: (tx: Tx, actor: Actor) => Promise<WriteResult<T>>,
) {
  const actor = actorOf(req);
  const key = req.headers['idempotency-key'] as string | undefined;
  const res = await idempotentWrite(actor, key, action, { params: req.params, body: req.body ?? null }, (tx) => fn(tx, actor));
  if (res.replayed) reply.header('Idempotent-Replay', 'true');
  return reply.status(res.status).send(res.body);
}

export function buildApp() {
  const app = Fastify({ logger: process.env.NODE_ENV !== 'test' });
  app.register(formbody);

  app.setErrorHandler((e, _req, reply) => {
    const err = e as Error & { statusCode?: number };
    if (err instanceof AppError) return reply.status(err.status).send(toErrorBody(err));
    // Database guards raise RECORD_LOCKED when something tries to edit an append-only row.
    if (typeof err.message === 'string' && err.message.startsWith('RECORD_LOCKED')) {
      return reply.status(405).send(toErrorBody(new AppError('RECORD_LOCKED', 'This record cannot be changed')));
    }
    if ((err as { validation?: unknown }).validation || err.statusCode === 400) {
      return reply.status(422).send(toErrorBody(new AppError('VALIDATION_FAILED', err.message)));
    }
    app.log.error(err);
    return reply.status(500).send({ error: { code: 'INTERNAL', message: 'Something went wrong' } });
  });

  // Bearer token -> actor with current role grants (revocations take effect at once).
  app.addHook('preHandler', async (req) => {
    const h = req.headers.authorization;
    if (!h?.startsWith('Bearer ')) return;
    const userId = verifyToken(h.slice(7));
    const actor = await loadActor(userId, channelOf(req));
    if (!actor) throw new AppError('UNAUTHENTICATED', 'Sign in again');
    const device = req.headers['x-device-id'];
    if (typeof device === 'string') actor.deviceId = device;
    req.actor = actor;
  });

  app.get('/health', async () => ({ ok: true }));

  // ------------------------------------------------------------ auth
  app.post('/auth/login', async (req) => {
    const b = parse(z.object({ phone: z.string(), pin: z.string() }), req.body);
    const { userId } = await checkPin(b.phone, b.pin);
    const actor = (await loadActor(userId, channelOf(req)))!;
    return { token: signToken(userId), user: { userId, name: actor.name, phone: actor.phone }, roles: actor.grants };
  });

  app.get('/me', async (req) => {
    const a = actorOf(req);
    return { userId: a.userId, name: a.name, phone: a.phone, roles: a.grants };
  });

  app.post('/auth/change-pin', async (req, reply) => {
    const actor = actorOf(req);
    const b = parse(z.object({ oldPin: z.string(), newPin: z.string().regex(/^\d{4}$/) }), req.body);
    await withTx((tx) => changePin(tx, actor, b.oldPin, b.newPin));
    return reply.status(204).send();
  });

  // ------------------------------------------------------------ admin (paths proposed, register D33)
  app.post('/cooperatives', (req, reply) =>
    write(req, reply, 'cooperative.create', async (tx, actor) => {
      const b = parse(z.object({ name: z.string().min(2) }), req.body);
      return { status: 201, body: await admin.createCooperative(tx, actor, b.name) };
    }),
  );

  app.post('/admin/users', (req, reply) =>
    write(req, reply, 'user.create', async (tx, actor) => {
      const b = parse(
        z.object({ phone: z.string(), name: z.string().min(2), role: z.string(), scopeId: z.string().nullish() }),
        req.body,
      );
      // Authorised by grantRole below; the user row rolls back if the grant is refused.
      const user = await admin.findOrCreateUser(tx, actor, b.phone, b.name);
      const grant = await admin.grantRole(tx, actor, { userId: user.userId, role: b.role, scopeId: b.scopeId });
      return { status: 201, body: { userId: user.userId, phone: user.phone, created: user.created, grant } };
    }),
  );

  app.post('/admin/role-grants', (req, reply) =>
    write(req, reply, 'role.grant', async (tx, actor) => {
      const b = parse(z.object({ userId: z.string(), role: z.string(), scopeId: z.string().nullish() }), req.body);
      return { status: 201, body: await admin.grantRole(tx, actor, b) };
    }),
  );

  app.post('/admin/role-grants/:grantId/revoke', (req, reply) =>
    write(req, reply, 'role.revoke', async (tx, actor) => {
      const { grantId } = req.params as { grantId: string };
      return { status: 200, body: await admin.revokeRole(tx, actor, grantId) };
    }),
  );

  // ------------------------------------------------------------ farms and animals
  app.post('/cooperatives/:coopId/farms', (req, reply) =>
    write(req, reply, 'farm.create', async (tx, actor) => {
      const { coopId } = req.params as { coopId: string };
      const b = parse(
        z.object({
          name: z.string().min(2),
          phone: z.string(),
          identityNumber: z.string().min(4),
          route: z.string().nullish(),
          farmerName: z.string().optional(),
        }),
        req.body,
      );
      return { status: 201, body: await farmer.createFarm(tx, actor, coopId, b) };
    }),
  );

  app.get('/farms/:farmId', async (req) => farmer.getFarm(actorOf(req), (req.params as { farmId: string }).farmId));

  app.post('/farms/:farmId/animals', (req, reply) =>
    write(req, reply, 'animal.create', async (tx, actor) => {
      const { farmId } = req.params as { farmId: string };
      const b = parse(z.object({ tag: z.string().min(1).max(30), name: z.string().max(40).nullish() }), req.body);
      return { status: 201, body: await farmer.addAnimal(tx, actor, farmId, b) };
    }),
  );

  app.get('/farms/:farmId/animals', async (req) =>
    farmer.listAnimals(actorOf(req), (req.params as { farmId: string }).farmId),
  );

  // ------------------------------------------------------------ farmer stage (brief section 4)
  app.post('/farms/:farmId/amr', (req, reply) =>
    write(req, reply, 'amr.create', async (tx, actor) => {
      const { farmId } = req.params as { farmId: string };
      const b = parse(
        z.object({
          milkDate: date,
          session,
          animalId: z.string(),
          litres: z.number(),
          confirmLarge: z.boolean().optional(),
        }),
        req.body,
      );
      return { status: 201, body: await farmer.recordAmr(tx, actor, farmId, { ...b, deviceId: actor.deviceId }) };
    }),
  );

  app.get('/farms/:farmId/recent-milk', async (req) =>
    farmer.recentMilk(actorOf(req), (req.params as { farmId: string }).farmId, dateParam(req.query)),
  );

  app.get('/farms/:farmId/milk-sessions', async (req) =>
    farmer.milkSessions(actorOf(req), (req.params as { farmId: string }).farmId, dateParam(req.query)),
  );

  app.post('/farms/:farmId/farm-lots', (req, reply) =>
    write(req, reply, 'farm_lot.create', async (tx, actor) => {
      const { farmId } = req.params as { farmId: string };
      const b = parse(
        z.object({ date, scope: z.enum(['morning', 'afternoon', 'evening', 'all']), litres: z.number().optional() }),
        req.body,
      );
      return { status: 201, body: await farmer.commitFarmLot(tx, actor, farmId, b) };
    }),
  );

  app.get('/farms/:farmId/farm-lots', async (req) =>
    farmer.listFarmLots(actorOf(req), (req.params as { farmId: string }).farmId, dateParam(req.query)),
  );

  app.post('/farms/:farmId/farm-lots/:farmLotId/withdraw', (req, reply) =>
    write(req, reply, 'farm_lot.withdraw', async (tx, actor) => {
      const { farmId, farmLotId } = req.params as { farmId: string; farmLotId: string };
      const b = parse(z.object({ reason: z.string().max(200).optional() }).nullish(), req.body);
      return { status: 200, body: await farmer.withdrawFarmLot(tx, actor, farmId, farmLotId, b?.reason) };
    }),
  );

  // Append-only: there is deliberately no PUT/PATCH/DELETE on farm lots.
  app.route({
    method: ['PUT', 'PATCH', 'DELETE'],
    url: '/farms/:farmId/farm-lots/:farmLotId',
    handler: async () => {
      throw new AppError('RECORD_LOCKED', 'Farm lots cannot be edited or deleted; file a correction');
    },
  });

  // ------------------------------------------------------------ regulator (paths proposed)
  app.get('/regulator/daily-roots/:date', async (req) =>
    regulator.getDailyRoot(actorOf(req), parse(date, (req.params as { date: string }).date)),
  );
  app.get('/regulator/chains/:chainKey/verify', async (req) =>
    regulator.checkChain(actorOf(req), (req.params as { chainKey: string }).chainKey),
  );

  // ------------------------------------------------------------ USSD gateway
  app.post('/ussd', async (req, reply) => {
    const key = (req.query as { key?: string }).key;
    if (key !== config.ussdGatewayKey) return reply.status(403).type('text/plain').send('END Not allowed');
    const b = req.body as Record<string, string | undefined>;
    const text = await handleUssd({ sessionId: b.sessionId ?? '', phoneNumber: b.phoneNumber ?? '', text: b.text ?? '' });
    return reply.type('text/plain').send(text);
  });

  return app;
}
