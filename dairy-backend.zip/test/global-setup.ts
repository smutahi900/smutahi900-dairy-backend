import pg from 'pg';

export async function setup() {
  process.env.NODE_ENV = 'test';
  const url = process.env.DATABASE_URL ?? 'postgres://dairy:dairy@localhost:5432/dairy_test';
  const c = new pg.Client({ connectionString: url });
  await c.connect();
  await c.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await c.end();
  const { migrate } = await import('../src/db/migrate.js');
  const { pool } = await import('../src/db/pool.js');
  await migrate(() => {});
  await pool.end();
}
