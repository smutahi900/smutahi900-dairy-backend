import { randomUUID } from 'node:crypto';
import { afterAll, beforeEach } from 'vitest';
import { buildApp } from '../src/app.js';
import { pool, withTx } from '../src/db/pool.js';
import { SYSTEM_ACTOR } from '../src/lib/actor.js';
import { setClock } from '../src/lib/clock.js';
import { newId } from '../src/lib/ids.js';
import { hashPin } from '../src/modules/auth/service.js';
import { grantRole } from '../src/modules/admin/service.js';

export const app = buildApp();

/** 2026-11-04 09:00 in Nairobi. */
export const TODAY = '2026-11-04';
export const NOON_UTC = new Date('2026-11-04T06:00:00Z');

/** A clock that moves 1 ms each time it is read, so records get distinct times. */
export function tickingClock(start: Date) {
  let t = start.getTime();
  setClock(() => new Date(t++));
}

export function useTestDb() {
  beforeEach(async () => {
    tickingClock(NOON_UTC);
    const t = await pool.query<{ tablename: string }>(
      `SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename <> 'schema_migration'`,
    );
    await pool.query(`TRUNCATE ${t.rows.map((r) => `"${r.tablename}"`).join(', ')} CASCADE`);
  });
  afterAll(async () => {
    setClock(null);
  });
}

let phoneCounter = 100000;
export function nextPhone() {
  phoneCounter++;
  return `07${String(phoneCounter).padStart(8, '0')}`;
}

export interface Client {
  token: string;
  userId: string;
  phone: string;
  get: (url: string) => Promise<{ status: number; body: any; headers: Record<string, unknown> }>;
  post: (url: string, body?: unknown, key?: string | null) => Promise<{ status: number; body: any; headers: Record<string, unknown> }>;
}

export function client(token: string, userId = '', phone = ''): Client {
  const call = async (method: 'GET' | 'POST', url: string, body?: unknown, key?: string | null) => {
    const headers: Record<string, string> = { authorization: `Bearer ${token}` };
    if (method === 'POST' && key !== null) headers['idempotency-key'] = key ?? randomUUID();
    const r = await app.inject({ method, url, headers, payload: body as any });
    return { status: r.statusCode, body: r.body ? JSON.parse(r.body) : null, headers: r.headers };
  };
  return {
    token, userId, phone,
    get: (url) => call('GET', url),
    post: (url, body, key) => call('POST', url, body ?? {}, key),
  };
}

export async function login(phone: string, pin: string): Promise<Client> {
  const r = await app.inject({ method: 'POST', url: '/auth/login', payload: { phone, pin } });
  if (r.statusCode !== 200) throw new Error(`login failed: ${r.body}`);
  const b = JSON.parse(r.body);
  return client(b.token, b.user.userId, b.user.phone);
}

/** A user created directly (bootstrap only, like scripts/seed.ts). */
export async function bootstrapUser(role: 'platform_admin' | 'regulator', pin = '1111'): Promise<Client> {
  const phone = nextPhone();
  const userId = newId('US');
  await withTx(async (tx) => {
    await tx.query(
      `INSERT INTO app_user(user_id, phone, name, pin_hash, channel) VALUES ($1,$2,$3,$4,'system')`,
      [userId, phone.replace(/^0/, '+254'), role, await hashPin(pin)],
    );
    await grantRole(tx, SYSTEM_ACTOR, { userId, role }, { skipAuth: true });
  });
  return login(phone, pin);
}

/** The one-time PIN the back end queued by SMS for this phone. */
export async function pinFromSms(phone: string): Promise<string> {
  const e164 = phone.replace(/^0/, '+254');
  const r = await pool.query<{ body: string }>(
    `SELECT body FROM sms_outbox WHERE phone = $1 AND purpose = 'welcome_pin' ORDER BY created_at DESC LIMIT 1`,
    [e164],
  );
  return r.rows[0].body.match(/PIN is (\d{4})/)![1];
}

/** Admin, cooperative, cooperative owner, one farm with a farmer and two animals. */
export async function world() {
  const admin = await bootstrapUser('platform_admin');
  const coop = (await admin.post('/cooperatives', { name: 'Kiambu Dairy Co-op' })).body;
  const ownerPhone = nextPhone();
  await admin.post('/admin/users', { phone: ownerPhone, name: 'Owner', role: 'cooperative_owner', scopeId: coop.coopId });
  const owner = await login(ownerPhone, await pinFromSms(ownerPhone));
  const farm = await newFarm(owner, coop.coopId);
  return { admin, coop, owner, ...farm };
}

export async function newFarm(owner: Client, coopId: string) {
  const farmerPhone = nextPhone();
  const r = await owner.post(`/cooperatives/${coopId}/farms`, {
    name: 'Wanjiku Farm', phone: farmerPhone, identityNumber: '12345678', route: 'Route 4',
  });
  if (r.status !== 201) throw new Error(JSON.stringify(r.body));
  const farmId: string = r.body.farmId;
  const farmerPin = await pinFromSms(farmerPhone);
  const farmer = await login(farmerPhone, farmerPin);
  const daisy = (await farmer.post(`/farms/${farmId}/animals`, { tag: 'KE001', name: 'Daisy' })).body;
  const bella = (await farmer.post(`/farms/${farmId}/animals`, { tag: 'KE002', name: 'Bella' })).body;
  return { farmId, farmer, farmerPhone, farmerPin, daisy, bella };
}
