import { describe, expect, it } from 'vitest';
import { pool } from '../src/db/pool.js';
import { TODAY, tickingClock, useTestDb, world } from './helpers.js';

useTestDb();

async function setup() {
  const w = await world();
  const amr = (session: string, animalId: string, litres: number, extra: object = {}) =>
    w.farmer.post(`/farms/${w.farmId}/amr`, { milkDate: TODAY, session, animalId, litres, ...extra });
  const commit = (scope: string, extra: object = {}) =>
    w.farmer.post(`/farms/${w.farmId}/farm-lots`, { date: TODAY, scope, ...extra });
  const sessions = async () => (await w.farmer.get(`/farms/${w.farmId}/milk-sessions?date=today`)).body;
  return { ...w, amr, commit, sessions };
}

describe('animal milk records', () => {
  it('records milk and adds it up per session', async () => {
    const t = await setup();
    expect((await t.amr('morning', t.daisy.animalId, 12.5)).status).toBe(201);
    await t.amr('morning', t.bella.animalId, 8);
    await t.amr('evening', t.daisy.animalId, 10.3);
    const s = await t.sessions();
    expect(s.sessions.find((x: any) => x.session === 'morning')).toMatchObject({ grossLitres: 20.5, freeLitres: 20.5, records: 2 });
    expect(s.total).toEqual({ grossLitres: 30.8, committedLitres: 0, freeLitres: 30.8 });
    const recent = (await t.farmer.get(`/farms/${t.farmId}/recent-milk?date=today`)).body;
    expect(recent.map((r: any) => r.tag)).toEqual(['KE001', 'KE002', 'KE001']);
  });

  it('needs confirmation above 500 L', async () => {
    const t = await setup();
    const r = await t.amr('morning', t.daisy.animalId, 500.1);
    expect(r.status).toBe(422);
    expect(r.body.error.code).toBe('CONFIRMATION_REQUIRED');
    expect((await t.amr('morning', t.daisy.animalId, 500)).status).toBe(201);
    expect((await t.amr('morning', t.daisy.animalId, 501, { confirmLarge: true })).status).toBe(201);
  });

  it('rejects more than one decimal, zero, future dates and other farms\' animals', async () => {
    const t = await setup();
    expect((await t.amr('morning', t.daisy.animalId, 1.25)).body.error.code).toBe('VALIDATION_FAILED');
    expect((await t.amr('morning', t.daisy.animalId, 0)).body.error.code).toBe('VALIDATION_FAILED');
    const f = await t.farmer.post(`/farms/${t.farmId}/amr`, { milkDate: '2026-11-05', session: 'morning', animalId: t.daisy.animalId, litres: 1 });
    expect(f.body.error.code).toBe('DATE_IN_FUTURE');
    expect((await t.amr('morning', 'AN-NOTMINE', 1)).body.error.code).toBe('ANIMAL_NOT_FOUND');
  });
});

describe('committing farm lots', () => {
  it('commits a session into an FL- lot awaiting collection, with litres from each AMR', async () => {
    const t = await setup();
    const a1 = (await t.amr('morning', t.daisy.animalId, 12.5)).body;
    const a2 = (await t.amr('morning', t.bella.animalId, 8)).body;
    const r = await t.commit('morning');
    expect(r.status).toBe(201);
    expect(r.body.farmLotId).toMatch(/^FL-[0-9A-Z]{8}$/);
    expect(r.body).toMatchObject({ status: 'awaiting_collection', committedLitres: 20.5, scope: 'morning' });
    expect(r.body.amrs).toEqual(expect.arrayContaining([
      { amrId: a1.amrId, litres: 12.5 }, { amrId: a2.amrId, litres: 8 },
    ]));
    const trail = await pool.query(`SELECT event, from_status, to_status, actor FROM trail_event WHERE record_id = $1`, [r.body.farmLotId]);
    expect(trail.rows).toEqual([{ event: 'created', from_status: null, to_status: 'awaiting_collection', actor: t.farmer.userId }]);
  });

  it('locks every AMR of a committed session; other sessions stay open', async () => {
    const t = await setup();
    await t.amr('morning', t.daisy.animalId, 10);
    await t.commit('morning');
    const late = await t.amr('morning', t.bella.animalId, 4);
    expect(late.status).toBe(405);
    expect(late.body.error.code).toBe('RECORD_LOCKED');
    expect((await t.amr('evening', t.bella.animalId, 4)).status).toBe(201);
    const s = await t.sessions();
    expect(s.sessions.find((x: any) => x.session === 'morning').locked).toBe(true);
    expect(s.sessions.find((x: any) => x.session === 'evening').locked).toBe(false);
  });

  it('never commits more than gross: EXCEEDS_GROSS and NO_GROSS_MILK', async () => {
    const t = await setup();
    expect((await t.commit('morning')).body.error.code).toBe('NO_GROSS_MILK');
    await t.amr('morning', t.daisy.animalId, 10);
    const over = await t.commit('morning', { litres: 10.1 });
    expect(over.body.error.code).toBe('EXCEEDS_GROSS');
    expect(over.body.error.details).toEqual({ requestedLitres: 10.1, freeLitres: 10 });
    // part now, the rest later
    expect((await t.commit('morning', { litres: 6 })).body.committedLitres).toBe(6);
    expect((await t.commit('morning')).body.committedLitres).toBe(4);
    expect((await t.commit('morning')).body.error.code).toBe('NO_GROSS_MILK');
    expect((await t.sessions()).total).toEqual({ grossLitres: 10, committedLitres: 10, freeLitres: 0 });
  });

  it('"all" commits every session of today', async () => {
    const t = await setup();
    await t.amr('morning', t.daisy.animalId, 10);
    await t.amr('afternoon', t.daisy.animalId, 5);
    await t.commit('morning', { litres: 4 });
    const all = await t.commit('all');
    expect(all.body).toMatchObject({ scope: 'all', committedLitres: 11 });
    expect((await t.sessions()).sessions.every((s: any) => s.freeLitres === 0)).toBe(true);
  });

  it('only today\'s milk can be committed (NOT_TODAY)', async () => {
    const t = await setup();
    await t.farmer.post(`/farms/${t.farmId}/amr`, { milkDate: '2026-11-03', session: 'evening', animalId: t.daisy.animalId, litres: 5 });
    const r = await t.farmer.post(`/farms/${t.farmId}/farm-lots`, { date: '2026-11-03', scope: 'evening' });
    expect(r.body.error.code).toBe('NOT_TODAY');
  });

  it('uses Nairobi midnight as the cut-off, not UTC', async () => {
    const t = await setup();
    // 22:30 UTC on 3 Nov is 01:30 on 4 Nov in Nairobi
    tickingClock(new Date('2026-11-03T22:30:00Z'));
    await t.amr('morning', t.daisy.animalId, 5);
    expect((await t.commit('morning')).status).toBe(201);
    // 21:30 UTC on 4 Nov is 00:30 on 5 Nov in Nairobi: 4 Nov is closed
    tickingClock(new Date('2026-11-04T21:30:00Z'));
    expect((await t.commit('morning')).body.error.code).toBe('NOT_TODAY');
  });

  it('two commits at the same moment cannot overcommit', async () => {
    const t = await setup();
    await t.amr('morning', t.daisy.animalId, 10);
    const rs = await Promise.all([t.commit('morning', { litres: 7 }), t.commit('morning', { litres: 7 })]);
    expect(rs.map((r) => r.status).sort()).toEqual([201, 422]);
  });
});

describe('withdrawing and append-only records', () => {
  it('withdraws an awaiting lot, frees its litres, and refuses a second withdraw', async () => {
    const t = await setup();
    await t.amr('morning', t.daisy.animalId, 10);
    const lot = (await t.commit('morning')).body;
    const w = await t.farmer.post(`/farms/${t.farmId}/farm-lots/${lot.farmLotId}/withdraw`, { reason: 'spilt' });
    expect(w.status).toBe(200);
    expect(w.body.status).toBe('withdrawn');
    expect((await t.sessions()).total.freeLitres).toBe(10);
    const again = await t.farmer.post(`/farms/${t.farmId}/farm-lots/${lot.farmLotId}/withdraw`);
    expect(again.body.error.code).toBe('LOT_NOT_WITHDRAWABLE');
    const trail = await pool.query(`SELECT to_status, reason FROM trail_event WHERE record_id = $1 ORDER BY at, event_id`, [lot.farmLotId]);
    expect(trail.rows.map((r) => r.to_status)).toEqual(['awaiting_collection', 'withdrawn']);
    // AMRs stay locked; freed litres can be committed again
    expect((await t.amr('morning', t.bella.animalId, 1)).body.error.code).toBe('RECORD_LOCKED');
    expect((await t.commit('morning')).body.committedLitres).toBe(10);
  });

  it('has no edit or delete endpoint for farm lots', async () => {
    const t = await setup();
    await t.amr('morning', t.daisy.animalId, 10);
    const lot = (await t.commit('morning')).body;
    for (const method of ['PUT', 'PATCH', 'DELETE'] as const) {
      const { app } = await import('./helpers.js');
      const r = await app.inject({ method, url: `/farms/${t.farmId}/farm-lots/${lot.farmLotId}`, headers: { authorization: `Bearer ${t.farmer.token}` } });
      expect(r.statusCode).toBe(405);
    }
  });

  it('the database itself refuses edits to fixed columns and deletes', async () => {
    const t = await setup();
    const a = (await t.amr('morning', t.daisy.animalId, 10)).body;
    const lot = (await t.commit('morning')).body;
    await expect(pool.query(`UPDATE farm_lot SET committed_x10 = 999 WHERE farm_lot_id = $1`, [lot.farmLotId])).rejects.toThrow(/RECORD_LOCKED/);
    await expect(pool.query(`DELETE FROM farm_lot WHERE farm_lot_id = $1`, [lot.farmLotId])).rejects.toThrow(/RECORD_LOCKED/);
    await expect(pool.query(`UPDATE amr SET litres_x10 = 1 WHERE amr_id = $1`, [a.amrId])).rejects.toThrow(/RECORD_LOCKED/);
    await expect(pool.query(`UPDATE amr SET locked = false WHERE amr_id = $1`, [a.amrId])).rejects.toThrow(/RECORD_LOCKED/);
    await expect(pool.query(`DELETE FROM trail_event`)).rejects.toThrow(/RECORD_LOCKED/);
  });
});
