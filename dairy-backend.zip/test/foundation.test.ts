import { describe, expect, it } from 'vitest';
import { pool } from '../src/db/pool.js';
import { app, bootstrapUser, client, login, newFarm, nextPhone, pinFromSms, useTestDb, world } from './helpers.js';

useTestDb();

describe('sign-in with PIN', () => {
  it('signs in and returns roles', async () => {
    const { farmer, farmId } = await world();
    const me = await farmer.get('/me');
    expect(me.status).toBe(200);
    expect(me.body.roles).toEqual([expect.objectContaining({ role: 'farmer', scopeType: 'farm', scopeId: farmId })]);
  });

  it('gives the same answer for an unknown phone and a wrong PIN', async () => {
    const { farmerPhone } = await world();
    const a = await app.inject({ method: 'POST', url: '/auth/login', payload: { phone: farmerPhone, pin: '0000' } });
    const b = await app.inject({ method: 'POST', url: '/auth/login', payload: { phone: '0799999999', pin: '0000' } });
    expect(a.statusCode).toBe(401);
    expect(b.statusCode).toBe(401);
    expect(JSON.parse(a.body).error.code).toBe('PIN_INVALID');
    expect(JSON.parse(b.body).error.code).toBe('PIN_INVALID');
  });

  it('locks the PIN after 5 wrong tries, even for the right PIN', async () => {
    const { farmerPhone, farmerPin } = await world();
    const codes: string[] = [];
    for (let i = 0; i < 5; i++) {
      const r = await app.inject({ method: 'POST', url: '/auth/login', payload: { phone: farmerPhone, pin: '0000' } });
      codes.push(JSON.parse(r.body).error.code);
    }
    expect(codes).toEqual(['PIN_INVALID', 'PIN_INVALID', 'PIN_INVALID', 'PIN_INVALID', 'PIN_LOCKED']);
    const r = await app.inject({ method: 'POST', url: '/auth/login', payload: { phone: farmerPhone, pin: farmerPin } });
    expect(JSON.parse(r.body).error.code).toBe('PIN_LOCKED');
  });

  it('refuses calls without a token', async () => {
    const r = await app.inject({ method: 'GET', url: '/me' });
    expect(r.statusCode).toBe(401);
    const bad = await client('not-a-token').get('/me');
    expect(bad.body.error.code).toBe('UNAUTHENTICATED');
  });

  it('changes the PIN', async () => {
    const { farmer, farmerPhone, farmerPin } = await world();
    const r = await app.inject({
      method: 'POST', url: '/auth/change-pin', headers: { authorization: `Bearer ${farmer.token}` },
      payload: { oldPin: farmerPin, newPin: '2468' },
    });
    expect(r.statusCode).toBe(204);
    await expect(login(farmerPhone, farmerPin)).rejects.toThrow();
    await login(farmerPhone, '2468');
  });
});

describe('roles and scope (D33)', () => {
  it('refuses another farmer\'s farm with FORBIDDEN_ROLE and logs it', async () => {
    const { owner, coop, farmer } = await world();
    const other = await newFarm(owner, coop.coopId);
    const r = await farmer.get(`/farms/${other.farmId}/milk-sessions?date=today`);
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe('FORBIDDEN_ROLE');
    const log = await pool.query(`SELECT * FROM access_log WHERE user_id = $1 AND NOT allowed`, [farmer.userId]);
    expect(log.rows).toHaveLength(1);
    expect(log.rows[0]).toMatchObject({ action: 'amr.read', resource: other.farmId, reason: 'out of scope' });
  });

  it('a farmer cannot do cooperative actions (deny by default)', async () => {
    const { farmer, coop } = await world();
    const r = await farmer.post(`/cooperatives/${coop.coopId}/farms`, { name: 'X Farm', phone: nextPhone(), identityNumber: '9999' });
    expect(r.body.error.code).toBe('FORBIDDEN_ROLE');
  });

  it('a cooperative owner is limited to their own cooperative', async () => {
    const { admin, owner } = await world();
    const other = (await admin.post('/cooperatives', { name: 'Other co-op' })).body;
    const r = await owner.post(`/cooperatives/${other.coopId}/farms`, { name: 'X Farm', phone: nextPhone(), identityNumber: '9999' });
    expect(r.status).toBe(403);
  });

  it('a cooperative owner can see their farms but cannot record milk for the farmer', async () => {
    const { owner, farmId, daisy } = await world();
    expect((await owner.get(`/farms/${farmId}/milk-sessions?date=today`)).status).toBe(200);
    const r = await owner.post(`/farms/${farmId}/amr`, { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 5 });
    expect(r.body.error.code).toBe('FORBIDDEN_ROLE');
  });

  it('a cooperative owner cannot grant platform roles', async () => {
    const { owner, farmer } = await world();
    const r = await owner.post('/admin/role-grants', { userId: farmer.userId, role: 'regulator' });
    expect(r.status).toBe(403);
    // and the refused user creation leaves no user behind
    const phone = nextPhone();
    await owner.post('/admin/users', { phone, name: 'Sneaky', role: 'platform_admin' });
    const u = await pool.query(`SELECT 1 FROM app_user WHERE phone = $1`, [phone.replace(/^0/, '+254')]);
    expect(u.rows).toHaveLength(0);
  });

  it('one phone can hold several roles, each checked on its own', async () => {
    const { owner, coop, farmer, farmId } = await world();
    const g = await owner.post('/admin/role-grants', { userId: farmer.userId, role: 'collector', scopeId: coop.coopId });
    expect(g.status).toBe(201);
    const me = await farmer.get('/me');
    expect(me.body.roles.map((r: any) => r.role).sort()).toEqual(['collector', 'farmer']);
    // collector role does not give farm-creation rights
    expect((await farmer.post(`/cooperatives/${coop.coopId}/farms`, { name: 'Y Farm', phone: nextPhone(), identityNumber: '8888' })).status).toBe(403);
    // still a farmer on the farm
    expect((await farmer.get(`/farms/${farmId}/farm-lots?date=today`)).status).toBe(200);
  });

  it('a revoked role stops working at once and both changes are logged', async () => {
    const { owner, coop } = await world();
    const phone = nextPhone();
    const created = await owner.post('/admin/users', { phone, name: 'Clerk', role: 'cooperative_clerk', scopeId: coop.coopId });
    const clerk = await login(phone, await pinFromSms(phone));
    expect((await clerk.post(`/cooperatives/${coop.coopId}/farms`, { name: 'Z Farm', phone: nextPhone(), identityNumber: '7777' })).status).toBe(201);
    await owner.post(`/admin/role-grants/${created.body.grant.grantId}/revoke`);
    expect((await clerk.post(`/cooperatives/${coop.coopId}/farms`, { name: 'Z2 Farm', phone: nextPhone(), identityNumber: '7778' })).status).toBe(403);
    const log = await pool.query(`SELECT action FROM access_log WHERE allowed AND action LIKE 'role.%' ORDER BY id`);
    expect(log.rows.map((r) => r.action)).toContain('role.revoked');
  });

  it('the first regulator onboards other regulators', async () => {
    const reg = await bootstrapUser('regulator');
    const r = await reg.post('/admin/users', { phone: nextPhone(), name: 'Inspector', role: 'regulator' });
    expect(r.status).toBe(201);
    const bad = await reg.post('/admin/users', { phone: nextPhone(), name: 'Admin?', role: 'platform_admin' });
    expect(bad.status).toBe(403);
  });
});

describe('idempotency', () => {
  it('requires an Idempotency-Key on writes', async () => {
    const { farmer, farmId } = await world();
    const r = await farmer.post(`/farms/${farmId}/animals`, { tag: 'KE009' }, null);
    expect(r.status).toBe(400);
    expect(r.body.error.code).toBe('IDEMPOTENCY_KEY_REQUIRED');
  });

  it('a retry with the same key returns the original record and creates nothing new', async () => {
    const { farmer, farmId, daisy } = await world();
    const body = { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 7.5 };
    const a = await farmer.post(`/farms/${farmId}/amr`, body, 'key-1');
    const b = await farmer.post(`/farms/${farmId}/amr`, body, 'key-1');
    expect(a.status).toBe(201);
    expect(b.status).toBe(201);
    expect(b.body).toEqual(a.body);
    expect(b.headers['idempotent-replay']).toBe('true');
    const n = await pool.query(`SELECT count(*)::int AS n FROM amr`);
    expect(n.rows[0].n).toBe(1);
  });

  it('concurrent retries with the same key still create one record', async () => {
    const { farmer, farmId, daisy } = await world();
    const body = { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 3 };
    const rs = await Promise.all([1, 2, 3, 4].map(() => farmer.post(`/farms/${farmId}/amr`, body, 'same')));
    expect(new Set(rs.map((r) => r.body.amrId)).size).toBe(1);
    expect((await pool.query(`SELECT count(*)::int AS n FROM amr`)).rows[0].n).toBe(1);
  });

  it('the same key with a different body is refused', async () => {
    const { farmer, farmId, daisy } = await world();
    await farmer.post(`/farms/${farmId}/amr`, { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 1 }, 'k');
    const r = await farmer.post(`/farms/${farmId}/amr`, { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 2 }, 'k');
    expect(r.body.error.code).toBe('IDEMPOTENCY_KEY_REUSED');
  });

  it('a failed write does not use up the key', async () => {
    const { farmer, farmId, daisy } = await world();
    const bad = await farmer.post(`/farms/${farmId}/amr`, { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 600 }, 'k2');
    expect(bad.body.error.code).toBe('CONFIRMATION_REQUIRED');
    const again = await farmer.post(`/farms/${farmId}/amr`, { milkDate: '2026-11-04', session: 'morning', animalId: daisy.animalId, litres: 600 }, 'k2');
    expect(again.body.error.code).toBe('CONFIRMATION_REQUIRED');
  });
});
