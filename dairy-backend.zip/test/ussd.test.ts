import { describe, expect, it } from 'vitest';
import { pool } from '../src/db/pool.js';
import { app, useTestDb, world } from './helpers.js';

useTestDb();

let n = 0;
/** Simulates the gateway: each hop sends the whole history joined by '*'. */
function dial(phone: string) {
  const sessionId = `ATUid_${++n}_${Date.now()}`;
  const inputs: string[] = [];
  const send = async (text: string) => {
    const r = await app.inject({
      method: 'POST', url: '/ussd?key=test-ussd-key',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      payload: new URLSearchParams({ sessionId, serviceCode: '*384*123#', phoneNumber: phone.replace(/^0/, '+254'), text }).toString(),
    });
    return r.body;
  };
  return {
    start: () => send(''),
    press: (v: string) => {
      inputs.push(v);
      return send(inputs.join('*'));
    },
    resend: () => send(inputs.join('*')),
  };
}

async function signedIn() {
  const w = await world();
  const s = dial(w.farmerPhone);
  expect(await s.start()).toBe('CON Welcome\nEnter your PIN');
  return { ...w, s };
}

describe('USSD', () => {
  it('refuses calls without the gateway key', async () => {
    const r = await app.inject({ method: 'POST', url: '/ussd', payload: { sessionId: 'x', phoneNumber: '+254700000000', text: '' } });
    expect(r.statusCode).toBe(403);
  });

  it('turns away unknown numbers and wrong PINs', async () => {
    expect(await dial('0711111111').start()).toMatch(/^END This number is not registered/);
    const { s } = await signedIn();
    expect(await s.press('0000')).toBe('END Wrong PIN (PIN_INVALID)');
  });

  it('records milk: menu, animal, session, litres, confirm', async () => {
    const { s, farmPin, farmId } = await signedIn().then((w) => ({ ...w, farmPin: w.farmerPin }));
    expect(await s.press(farmPin)).toBe('CON Dairy menu\n1 Record milk\n2 Commit milk\n3 Today\'s milk\n4 Withdraw a lot');
    expect(await s.press('1')).toBe('CON Choose animal\n1 KE001 Daisy\n2 KE002 Bella');
    expect(await s.press('1')).toBe('CON Session\n1 Morning\n2 Afternoon\n3 Evening');
    expect(await s.press('1')).toBe('CON Enter litres');
    expect(await s.press('12.5')).toBe('CON Save KE001, Morning, 12.5 L\n1 Yes\n2 No');
    expect(await s.press('1')).toBe('END Saved 12.5 L for KE001, Morning');
    const amr = await pool.query(`SELECT farm_id, litres_x10, channel FROM amr`);
    expect(amr.rows).toEqual([{ farm_id: farmId, litres_x10: 125, channel: 'ussd' }]);
  });

  it('re-asks after an invalid entry', async () => {
    const { s, farmerPin } = await signedIn();
    await s.press(farmerPin);
    expect(await s.press('7')).toBe('CON Invalid entry\nDairy menu\n1 Record milk\n2 Commit milk\n3 Today\'s milk\n4 Withdraw a lot');
    await s.press('1');
    await s.press('2');
    await s.press('3');
    expect(await s.press('abc')).toBe('CON Invalid entry\nEnter litres');
    expect(await s.press('4.25')).toBe('CON Invalid entry\nEnter litres');
    expect(await s.press('4')).toBe('CON Save KE002, Evening, 4.0 L\n1 Yes\n2 No');
  });

  it('asks again above 500 L', async () => {
    const { s, farmerPin } = await signedIn();
    for (const k of [farmerPin, '1', '1', '1']) await s.press(k);
    expect(await s.press('520')).toBe('CON 520.0 L is more than 500 L. Is it correct\n1 Yes\n2 No');
    expect(await s.press('1')).toBe('CON Save KE001, Morning, 520.0 L\n1 Yes\n2 No');
    expect(await s.press('1')).toBe('END Saved 520.0 L for KE001, Morning');
  });

  it('a resent last hop does not save twice', async () => {
    const { s, farmerPin } = await signedIn();
    for (const k of [farmerPin, '1', '1', '1', '3']) await s.press(k);
    const first = await s.press('1');
    const again = await s.resend();
    expect(again).toBe(first);
    expect((await pool.query(`SELECT count(*)::int AS n FROM amr`)).rows[0].n).toBe(1);
  });

  it('commits, shows today and withdraws, with the same rules as the web', async () => {
    const w = await world();
    const rec = dial(w.farmerPhone);
    await rec.start();
    for (const k of [w.farmerPin, '1', '1', '1', '10', '1']) await rec.press(k);

    const c = dial(w.farmerPhone);
    await c.start();
    await c.press(w.farmerPin);
    expect(await c.press('2')).toBe('CON Commit which milk\n1 Morning\n2 Afternoon\n3 Evening\n4 All today');
    expect(await c.press('1')).toBe('CON Commit 10.0 L of morning milk\n1 Yes\n2 No');
    const done = await c.press('1');
    expect(done).toMatch(/^END Committed FL-[0-9A-Z]{8}, 10\.0 L\. Awaiting collection$/);
    const lotId = done.match(/FL-[0-9A-Z]{8}/)![0];

    // same lock rule as the web: morning is now closed
    const late = dial(w.farmerPhone);
    await late.start();
    for (const k of [w.farmerPin, '1', '2', '1', '3']) await late.press(k);
    expect(await late.press('1')).toBe('END That session is committed and locked (RECORD_LOCKED)');

    const t = dial(w.farmerPhone);
    await t.start();
    await t.press(w.farmerPin);
    expect(await t.press('3')).toBe(`END Today\nMorning 10.0 L, free 0.0 L\n${lotId} 10.0 L awaiting collection`);

    const wd = dial(w.farmerPhone);
    await wd.start();
    await wd.press(w.farmerPin);
    expect(await wd.press('4')).toBe(`CON Withdraw which lot\n1 ${lotId} 10.0 L`);
    expect(await wd.press('1')).toBe(`CON Withdraw ${lotId}\n1 Yes\n2 No`);
    expect(await wd.press('1')).toBe(`END ${lotId} withdrawn`);

    // the web sees the same record and status
    const lots = (await w.farmer.get(`/farms/${w.farmId}/farm-lots?date=today`)).body;
    expect(lots).toEqual([expect.objectContaining({ farmLotId: lotId, status: 'withdrawn', channel: 'ussd' })]);
  });

  it('pages long animal lists with 98 More', async () => {
    const w = await world();
    for (let i = 3; i <= 9; i++) await w.farmer.post(`/farms/${w.farmId}/animals`, { tag: `KE00${i}` });
    const s = dial(w.farmerPhone);
    await s.start();
    await s.press(w.farmerPin);
    const p1 = await s.press('1');
    expect(p1.split('\n')).toHaveLength(1 + 6 + 1);
    expect(p1).toContain('98 More');
    const p2 = await s.press('98');
    expect(p2).toBe('CON Choose animal\n7 KE007\n8 KE008\n9 KE009');
    expect(await s.press('8')).toBe('CON Session\n1 Morning\n2 Afternoon\n3 Evening');
  });

  it('checks the PIN once per session, so later hops do not count as failures', async () => {
    const { s, farmerPin, farmerPhone } = await signedIn();
    for (const k of [farmerPin, '1', '1', '1', '2']) await s.press(k);
    await s.press('1');
    const u = await pool.query(`SELECT failed_pin_count FROM app_user WHERE phone = $1`, [farmerPhone.replace(/^0/, '+254')]);
    expect(u.rows[0].failed_pin_count).toBe(0);
  });
});
