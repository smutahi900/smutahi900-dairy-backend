import { describe, expect, it } from 'vitest';
import { pool } from '../src/db/pool.js';
import { canonicalJson, linkHash, GENESIS_HASH } from '../src/lib/hash.js';
import { storeDailyRoot } from '../src/modules/regulator/service.js';
import { bootstrapUser, TODAY, useTestDb, world } from './helpers.js';

useTestDb();

async function farmWithActivity() {
  const w = await world();
  await w.farmer.post(`/farms/${w.farmId}/amr`, { milkDate: TODAY, session: 'morning', animalId: w.daisy.animalId, litres: 10 });
  await w.farmer.post(`/farms/${w.farmId}/amr`, { milkDate: TODAY, session: 'morning', animalId: w.bella.animalId, litres: 6 });
  const lot = (await w.farmer.post(`/farms/${w.farmId}/farm-lots`, { date: TODAY, scope: 'morning' })).body;
  await w.farmer.post(`/farms/${w.farmId}/farm-lots/${lot.farmLotId}/withdraw`);
  return { ...w, lot };
}

describe('hash chain', () => {
  it('canonical JSON ignores key order', () => {
    expect(canonicalJson({ b: 1, a: { d: [1, 2], c: null } })).toBe('{"a":{"c":null,"d":[1,2]},"b":1}');
    expect(linkHash({ x: 1, y: 2 }, GENESIS_HASH)).toBe(linkHash({ y: 2, x: 1 }, GENESIS_HASH));
  });

  it('chains every farm record and status step, in order, per farm', async () => {
    const { farmId, lot } = await farmWithActivity();
    const links = await pool.query(`SELECT seq, record_type, prev_hash, hash FROM chain_link WHERE chain_key = $1 ORDER BY seq`, [`farm:${farmId}`]);
    expect(links.rows.map((l) => l.record_type)).toEqual(['farm', 'amr', 'amr', 'farm_lot', 'trail_event', 'trail_event']);
    expect(links.rows[0].prev_hash).toBe(GENESIS_HASH);
    for (let i = 1; i < links.rows.length; i++) expect(links.rows[i].prev_hash).toBe(links.rows[i - 1].hash);
    const row = await pool.query(`SELECT hash, prev_hash FROM farm_lot WHERE farm_lot_id = $1`, [lot.farmLotId]);
    expect(row.rows[0].hash).toBe(links.rows[3].hash);
  });

  it('the regulator can verify a chain and sees tampering', async () => {
    const { farmId, lot } = await farmWithActivity();
    const reg = await bootstrapUser('regulator');
    const key = encodeURIComponent(`farm:${farmId}`);
    const ok = await reg.get(`/regulator/chains/${key}/verify`);
    expect(ok.body).toMatchObject({ valid: true, links: 6 });

    // Someone with database access turns the guard off and edits the lot.
    await pool.query(`ALTER TABLE farm_lot DISABLE TRIGGER farm_lot_guard`);
    await pool.query(`UPDATE farm_lot SET hash = repeat('a', 64) WHERE farm_lot_id = $1`, [lot.farmLotId]);
    await pool.query(`ALTER TABLE farm_lot ENABLE TRIGGER farm_lot_guard`);
    const bad = await reg.get(`/regulator/chains/${key}/verify`);
    expect(bad.body).toMatchObject({ valid: false, brokenAt: { recordId: lot.farmLotId, problem: 'record hash differs from chain' } });
  });

  it('a changed chain payload breaks the hash', async () => {
    const { farmId } = await farmWithActivity();
    const reg = await bootstrapUser('regulator');
    await pool.query(`ALTER TABLE chain_link DISABLE TRIGGER chain_link_append_only`);
    await pool.query(
      `UPDATE chain_link SET payload = jsonb_set(payload, '{litresX10}', '999') WHERE chain_key = $1 AND seq = 2`,
      [`farm:${farmId}`],
    );
    await pool.query(`ALTER TABLE chain_link ENABLE TRIGGER chain_link_append_only`);
    const bad = await reg.get(`/regulator/chains/${encodeURIComponent(`farm:${farmId}`)}/verify`);
    expect(bad.body.brokenAt).toMatchObject({ seq: 2, problem: 'hash does not match payload' });
  });

  it('only the regulator reads chains', async () => {
    const { farmer, farmId } = await farmWithActivity();
    const r = await farmer.get(`/regulator/chains/${encodeURIComponent(`farm:${farmId}`)}/verify`);
    expect(r.status).toBe(403);
  });
});

describe('daily root', () => {
  it('stores one root per day, never overwrites it, and shows whether records still match', async () => {
    await farmWithActivity();
    const reg = await bootstrapUser('regulator');
    const first = await storeDailyRoot(TODAY);
    expect(first).toMatchObject({ stored: true, linkCount: 6 }); // the farm's 6 links; users and grants are not chained
    const again = await storeDailyRoot(TODAY);
    expect(again).toMatchObject({ stored: false, rootHash: first.rootHash });

    const r = await reg.get(`/regulator/daily-roots/${TODAY}`);
    expect(r.body).toMatchObject({ rootHash: first.rootHash, matchesRecords: true });

    await pool.query(`ALTER TABLE chain_link DISABLE TRIGGER chain_link_append_only`);
    await pool.query(`DELETE FROM chain_link WHERE seq = (SELECT max(seq) FROM chain_link)`);
    await pool.query(`ALTER TABLE chain_link ENABLE TRIGGER chain_link_append_only`);
    expect((await reg.get(`/regulator/daily-roots/${TODAY}`)).body.matchesRecords).toBe(false);
  });

  it('nobody can edit a stored root', async () => {
    await storeDailyRoot(TODAY);
    await expect(pool.query(`UPDATE daily_root SET root_hash = 'x'`)).rejects.toThrow(/RECORD_LOCKED/);
  });
});
