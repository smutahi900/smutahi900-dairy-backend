# Dairy chain back end

One back end for the farmer web, the role screens and USSD. Built from the
*Back-end Build Brief: Schema and API*, following its build order.

**Status:** build order step 1 (foundation) and step 2 (farmer) are done, plus
the farmer part of step 9 (USSD). 47 tests, all passing.

Stack: Node.js 20+, TypeScript, Fastify, PostgreSQL 14+.

## Run it

```bash
cp .env.example .env          # then edit the values
npm install
npm run migrate
ADMIN_PHONE=0700000001 ADMIN_PIN=4821 REGULATOR_PHONE=0700000002 REGULATOR_PIN=7314 npm run seed
npm run dev                   # http://localhost:3000
```

Tests use a separate database, `dairy_test`, which they wipe:

```bash
createdb dairy_test
npm test
```

Daily root, scheduled just after midnight Nairobi time (`15 0 * * *`, `TZ=Africa/Nairobi`):

```bash
npm run daily-root
```

## What is built

### Foundation (brief step 1)

| Piece | Where | Notes |
|---|---|---|
| Users, phone + 4-digit PIN | `modules/auth` | bcrypt hashes; 5 wrong PINs lock for 15 min; web and USSD share the counter; unknown phone and wrong PIN give the same answer |
| Roles and scope (D33) | `lib/rbac.ts` | deny by default; `PERMISSIONS` maps action → roles; each grant has a scope (platform, cooperative, farm, vendor); several roles per phone, each checked alone; refused calls → `FORBIDDEN_ROLE` 403, logged in `access_log` (outside the rolled-back transaction) |
| Role grant and removal | `modules/admin` | logged; a granter can only hand out roles listed in `GRANTABLE`, within their own scope; the first regulator onboards other regulators |
| Idempotency | `lib/idempotency.ts` | every write needs `Idempotency-Key`; a retry returns the stored response (header `Idempotent-Replay: true`); safe under concurrent retries; same key + different body → `IDEMPOTENCY_KEY_REUSED`; a failed write does not use up the key |
| Trail | `lib/trail.ts` | every status step writes who, when, from, to, reason; status changes only via `stepStatus` |
| Hash chain | `lib/chain.ts` | `hash = SHA-256(canonical JSON + prevHash)`; per farm (`farm:FARM-…`) for farm records, `batch:…` ready for batch events; every link kept in `chain_link`; `verifyChain` recomputes it and compares with each record |
| Daily root | `modules/regulator` | root over the day's links, written only by the job, never overwritten; the regulator API says whether the records still match it |
| Append-only in the database | migrations | triggers refuse `DELETE` and edits to fixed columns on `farm_lot`, `amr` (only locking allowed), `trail_event`, `chain_link`, `daily_root`, `correction`, so a bug in the code cannot get round the rule |
| SMS | `lib/sms.ts` | the back end queues messages in `sms_outbox`; no provider is wired yet (see next steps) |

### Farmer (brief step 2)

| Brief endpoint | Built | Errors |
|---|---|---|
| `POST /farms/{farmId}/amr` | yes | `RECORD_LOCKED`, `CONFIRMATION_REQUIRED` (> 500 L without `confirmLarge: true`), `DATE_IN_FUTURE`, `ANIMAL_NOT_FOUND` |
| `GET /farms/{farmId}/recent-milk?date=today` | yes | |
| `GET /farms/{farmId}/milk-sessions?date=today` | yes | gross, committed and free litres per session |
| `POST /farms/{farmId}/farm-lots` | yes | `EXCEEDS_GROSS`, `NO_GROSS_MILK`, `NOT_TODAY` |
| `GET /farms/{farmId}/farm-lots?date=today` | yes | |
| `POST /farms/{farmId}/farm-lots/{farmLotId}/withdraw` | yes | `LOT_NOT_WITHDRAWABLE` |

Rules enforced: only today's milk (Nairobi midnight cut-off) can be committed;
committed litres in active lots never exceed gross, even when two commits race;
each lot lists the litres it took from each AMR; once any part of a session is
committed, every AMR of that session is locked; a withdrawn lot frees its litres
but the AMRs stay locked; farm lots have no edit or delete endpoint
(`PUT/PATCH/DELETE` → `RECORD_LOCKED` 405). Litres are stored as integer tenths.

Also built, needed to get there (paths **proposed**, to reconcile with the portal team):

| Path | Role |
|---|---|
| `POST /auth/login`, `GET /me`, `POST /auth/change-pin` | anyone |
| `POST /cooperatives` | platform admin |
| `POST /admin/users` (create user + grant), `POST /admin/role-grants`, `POST /admin/role-grants/{grantId}/revoke` | admin, regulator, cooperative owner (within limits) |
| `POST /cooperatives/{coopId}/farms` (creates the farm code, the farmer user and their farmer role; PIN sent by SMS) | cooperative owner or clerk |
| `POST/GET /farms/{farmId}/animals`, `GET /farms/{farmId}` | farmer, cooperative |
| `GET /regulator/daily-roots/{date}`, `GET /regulator/chains/{chainKey}/verify` | regulator |

### USSD (farmer part of brief step 9)

`POST /ussd?key=<USSD_GATEWAY_KEY>` takes the Africa's Talking form fields
(`sessionId`, `phoneNumber`, `text`) and returns `CON …` / `END …`. It calls the
same services as the web, so it gives the same validation and error codes.

```
Welcome / Enter your PIN
1 Record milk    -> animal -> session -> litres -> (over 500 L: confirm) -> save
2 Commit milk    -> Morning / Afternoon / Evening / All today -> confirm
3 Today's milk   -> litres per session and today's lots
4 Withdraw a lot -> awaiting lots -> confirm
```

The PIN is checked once per session. An invalid entry shows the question again,
long lists page with `98 More`, and a resent last hop does not save twice.
Menu numbers have no full stop after them.

## Error format

```json
{ "error": { "code": "EXCEEDS_GROSS", "message": "…", "details": { "requestedLitres": 10.1, "freeLitres": 10 } } }
```

HTTP statuses from the brief: `FORBIDDEN_ROLE` 403, `RECORD_LOCKED` 405. The
rest were chosen here and are marked in `src/lib/errors.ts` for confirmation
(brief section 6).

## Assumptions to check

1. **The 12 role names** (`src/lib/rbac.ts`) are placeholders. The brief says 12 roles but the names are in the Roles and Access document. Rename them and update the permission table to match; the mechanism stays the same.
2. **USSD menu wording** is a first draft. Replace it with the texts from the USSD Developer Reference.
3. **Who creates farms**: the brief does not say. Here a cooperative owner or clerk registers the farm, and the farmer gets a one-time PIN by SMS.
4. **AMRs for past dates** are allowed (late entry) unless that session is locked. Only committing is limited to today.
5. **Channel** comes from the `X-Client-Channel: app|web` header (default `web`); USSD is set by the gateway endpoint. It will drive assurance (high / medium / low) in step 3.

## Next steps (brief build order)

3. Test profile and collector: profile versions, collect (`PROFILE_STALE`, `ASSURANCE_TOO_LOW`, `TEST_REQUIRED`), grade, collection batch, close, farmer SMS, plus an SMS provider worker that drains `sms_outbox`.
4. Cooperative: receiving lots, quality gate, production batch, farm lot trace-forward, price list.
5–11. Invoices, payments (M-Pesa stub until D2), dispatch and transport, vendor and consumer, the rest of USSD, regulator, statements and ledger.

## Layout

```
migrations/            SQL, applied in order by npm run migrate
src/app.ts             HTTP routes
src/lib/               errors, ids, clock (Nairobi), hash, chain, trail, rbac, idempotency, sms
src/modules/auth       PIN sign-in, tokens
src/modules/admin      cooperatives, users, role grants
src/modules/farmer     farms, animals, AMRs, farm lots
src/modules/ussd       USSD menu
src/modules/regulator  daily root, chain verification
scripts/               seed, daily-root
test/                  vitest against a real PostgreSQL
```
